//
//  Task.swift
//  TaskManagement
//
//  Created by Sarthak Marwah on 05/05/24.
//

import SwiftUI
import Firebase
import FirebaseFirestore

// Task Model

struct Task: Identifiable{
    var id = UUID().uuidString
    var taskTitle: String
    var taskDescription: String
    var taskDate: Date
}


class FirestoreService {
    private let db = Firestore.firestore()
    private let calendar = Calendar.current

    func fetchEventData(completion: @escaping ([Task]) -> Void) {
        guard let currentUserUID = Auth.auth().currentUser?.uid else {
            print("Error: Current user UID not available.")
            completion([])
            return
        }

        db.collection("eventRSVPs")
            .whereField("memberID", isEqualTo: currentUserUID)
            .getDocuments { snapshot, error in
                guard let snapshot = snapshot, error == nil else {
                    print("Error fetching documents: \(error?.localizedDescription ?? "Unknown error")")
                    completion([])
                    return
                }
                
                var tasks: [Task] = []
                
                for document in snapshot.documents {
                    if let eventName = document.data()["eventName"] as? String,
                       let eventDescription = document.data()["eventDescription"] as? String,
                       let eventDateTimestamp = document.data()["eventDate"] as? Timestamp {
                        let eventDate = eventDateTimestamp.dateValue()
                        let task = Task(taskTitle: "Event", taskDescription: eventName, taskDate: eventDate)
                        tasks.append(task)
                    }
                }
                
                completion(tasks)
            }
    }
    
    func fetchEvents(completion: @escaping ([Task]) -> Void) {
        guard let currentUserUID = Auth.auth().currentUser?.uid else {
            print("Error: Current user UID not available.")
            completion([])
            return
        }

        db.collection("eventRequests")
            .whereField("status", isEqualTo: "Accepted")
            .getDocuments { snapshot, error in
                guard let snapshot = snapshot, error == nil else {
                    print("Error fetching documents: \(error?.localizedDescription ?? "Unknown error")")
                    completion([])
                    return
                }
                
                var tasks: [Task] = []
                
                for document in snapshot.documents {
                    if let eventName = document.data()["eventName"] as? String,
                       let eventDescription = document.data()["eventDescription"] as? String,
                       let eventDateTimestamp = document.data()["eventDate"] as? Timestamp {
                        let eventDate = eventDateTimestamp.dateValue()
                        let task = Task(taskTitle: "Event", taskDescription: eventName, taskDate: eventDate)
                        tasks.append(task)
                    }
                }
                
                completion(tasks)
            }
    }

    func fetchEventReserveBook(completion: @escaping ([Task]) -> Void) {
        guard let currentUserUID = Auth.auth().currentUser?.uid else {
            print("Error: Current user UID not available.")
            completion([])
            return
        }
        
        db.collection("ReserveBook")
            .whereField("memberID", isEqualTo: currentUserUID)
            .getDocuments { snapshot, error in
                guard let snapshot = snapshot, error == nil else {
                    print("Error fetching documents: \(error?.localizedDescription ?? "Unknown error")")
                    completion([])
                    return
                }
                
                var tasks: [Task] = []
                
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "dd/MM/yyyy HH:mm"
                
                for document in snapshot.documents {
                    if let bookName = document.data()["bookName"] as? String,
                       let startTimeString = document.data()["startTime"] as? String,
                       let startTime = dateFormatter.date(from: startTimeString) {
                        
                        let task = Task(taskTitle: "Reserved Book", taskDescription: bookName, taskDate: startTime)
                        tasks.append(task)
                    }
                }
                
                completion(tasks)
        }
    }
    
    func fetchLibrarianSlots(completion: @escaping ([Task]) -> Void) {
        guard let currentUserUID = Auth.auth().currentUser?.uid else {
            print("Error: Current user UID not available.")
            completion([])
            return
        }
        
        db.collection("Slots")
            .getDocuments { snapshot, error in
                guard let snapshot = snapshot, error == nil else {
                    print("Error fetching documents: \(error?.localizedDescription ?? "Unknown error")")
                    completion([])
                    return
                }
                
                var tasks: [Task] = []
                
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "dd/MM/yyyy HH:mm"
                
                for document in snapshot.documents {
                    if let name = document.data()["name"] as? String,
                       let startTimeString = document.data()["startDate"] as? String,
                       let startTime = dateFormatter.date(from: startTimeString) {
                        
                        let task = Task(taskTitle: "Librarian Shift", taskDescription: name, taskDate: startTime)
                        tasks.append(task)
                    }
                }
                
                completion(tasks)
        }
    }
    
    func fetchLibrarianSlotsIndividual(completion: @escaping ([Task]) -> Void) {
        guard let currentUserUID = Auth.auth().currentUser?.uid else {
            print("Error: Current user UID not available.")
            completion([])
            return
        }
        
        db.collection("Slots")
            .whereField("id", isEqualTo: currentUserUID)
            .getDocuments { snapshot, error in
                guard let snapshot = snapshot, error == nil else {
                    print("Error fetching documents: \(error?.localizedDescription ?? "Unknown error")")
                    completion([])
                    return
                }
                
                var tasks: [Task] = []
                
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "dd/MM/yyyy HH:mm"
                
                for document in snapshot.documents {
                    if let Name = document.data()["name"] as? String,
                       let startTimeString = document.data()["startDate"] as? String,
                       let startTime = dateFormatter.date(from: startTimeString) {
                        
                        let task = Task(taskTitle: "My Shift", taskDescription: Name, taskDate: startTime)
                        tasks.append(task)
                    }
                }
                
                completion(tasks)
        }
    }
}
