//
//  TaskViewModelMember.swift
//  LMS3
//
//  Created by Aditya Majumdar on 08/05/24.
//

import SwiftUI
import Firebase
import FirebaseFirestore

class TaskViewModelMember: ObservableObject{
    
    // Sample Tasks
    @Published var storedTasks: [Task] = []

    //MARK: Current Week days
    @Published var currentWeek : [Date] = []
    
    //MARK: Current Day
    @Published var currentDay: Date = Date()
    
    // MARK: Filtering Today Tasks
    @Published var filteredTasks: [Task]?
    
    //MARK: Initialising
    init(){
        fetchCurrentWeek()
        setupTasks()
        filterTodayTasks()
    }
    
    // Setup tasks with specific dates
//    func setupTasks() {
//        let today = Date()
//        let calendar = Calendar.current
//
//        // We're creating task dates relative to today to ensure they show up
//        storedTasks = [
//            Task(taskTitle: "Meeting", taskDescription: "Discuss team task for the day", taskDate: calendar.date(byAdding: .day, value: 0, to: today)!),
//            Task(taskTitle: "Icon set", taskDescription: "Edit icons for team task for next week", taskDate: calendar.date(byAdding: .hour, value: -3, to: today)!),
//            Task(taskTitle: "Prototype", taskDescription: "Make and send prototype", taskDate: calendar.date(byAdding: .day, value: 2, to: today)!),
//            Task(taskTitle: "Check asset", taskDescription: "Start checking the assets", taskDate: calendar.date(byAdding: .day, value: 3, to: today)!),
//            Task(taskTitle: "Team party", taskDescription: "Make fun with team mates", taskDate: calendar.date(byAdding: .day, value: 4, to: today)!),
//            Task(taskTitle: "Client Meeting", taskDescription: "Explain project to client", taskDate: calendar.date(byAdding: .hour, value: -2, to: today)!),
//            Task(taskTitle: "Next Project", taskDescription: "Discuss next project with team", taskDate: calendar.date(byAdding: .hour, value: 3, to: today)!),
//            Task(taskTitle: "App Proposal", taskDescription: "Meet client for next App Proposal", taskDate: calendar.date(byAdding: .day, value: 6, to: today)!)
//        ]
//    }
    
    func setupTasks() {
        let firestoreService = FirestoreService()
        
        // Fetch tasks from Firestore
        firestoreService.fetchEventData { eventData in
            // Append fetched tasks to storedTasks
            self.storedTasks.append(contentsOf: eventData.map { task in
                Task(taskTitle: task.taskTitle, taskDescription: task.taskDescription, taskDate: task.taskDate)
            })
        }
        
        
        firestoreService.fetchEventReserveBook { reserveBooks in
            self.storedTasks.append(contentsOf: reserveBooks.map { task in
                Task(taskTitle: task.taskTitle, taskDescription: task.taskDescription, taskDate: task.taskDate)
            })
        }
        
       
    }

    
    // MARK: Filter Today Tasks
    func filterTodayTasks(){
        DispatchQueue.global(qos: .userInteractive).async {
            let calendar = Calendar.current
            let filtered = self.storedTasks.filter{
                return calendar.isDate($0.taskDate, inSameDayAs: self.currentDay)
            }
            
                .sorted { task1, task2 in
                    return task2.taskDate > task1.taskDate
                    
                }
            
            DispatchQueue.main.async {
                withAnimation{
                    self.filteredTasks = filtered
                }
            }
        }
    }
    
    func fetchCurrentWeek(){
        let today = Date()
        let calendar = Calendar.current
        let week = calendar.dateInterval(of: .weekOfMonth, for: today)
        
        guard let firstWeekDay = week?.start else {
            return
        }
        
        (0...6).forEach { day in
            if let weekday = calendar.date(byAdding: .day, value: day, to: firstWeekDay) {
                currentWeek.append(weekday)
            }
        }
    }
    
    //MARK: Extracting Date
    func extractDate(date: Date, format: String) -> String{
        let formatter = DateFormatter()
        formatter.dateFormat = format
        return formatter.string(from: date)
    }
    
    //MARK: Checking if current Date is Today
    func isToday(date: Date)->Bool{
        let calendar = Calendar.current
       // return calendar.isDateInToday(date)
        return calendar.isDate(currentDay, inSameDayAs: date)
    }
    
    //MARK: Checking if the currentHour is task Hour
    func isCurrentHour(date: Date)->Bool{
        
        let calendar = Calendar.current
        
        let hour = calendar.component(.hour, from: date)
        let currentHour = calendar.component(.hour, from: Date())
        
        return hour == currentHour
        
    }
}
