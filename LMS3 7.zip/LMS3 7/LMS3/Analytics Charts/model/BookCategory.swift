//
//  BookCategory.swift
//  BookstoreStategist
//
//  Created by Karin Prater on 16.07.23.
//



import Foundation


enum BookCategory: String, Identifiable, CaseIterable {
    case fiction
    case biography
    case children
    case computerScience
    case fantasy
    case business
  
    
    var id: Self { return self }
    
    var displayName: String {
        switch self {
            case .fiction:
                "Fiction"
            case .biography:
                "Biography"
            case .children:
                "Children Books"
            case .computerScience:
                "Computer Science"
            case .fantasy:
                "Fantasy"
            case .business:
                "Business"
        }
    }
}
//import Foundation
//import FirebaseFirestore
//import FirebaseFirestoreSwift
//
//struct CategoryAnalytics: Codable, Identifiable {
//    @DocumentID var id: String?
//    var name: String
//}
//
//class CategoryManager: ObservableObject {
//    @Published var categories: [Category] = []
//    
//    private var db = Firestore.firestore()
//    private var listenerRegistration: ListenerRegistration?
//    
//    init() {
//        fetchCategories()
//    }
//    
//    func fetchCategories() {
//        listenerRegistration = db.collection("categories").addSnapshotListener { querySnapshot, error in
//            guard let documents = querySnapshot?.documents else {
//                print("Error fetching categories: \(error?.localizedDescription ?? "Unknown error")")
//                return
//            }
//            
//            self.categories = documents.compactMap { document in
//                do {
//                    let category = try document.data(as: Category.self)
//                    return category
//                } catch {
//                    print("Error decoding category: \(error.localizedDescription)")
//                    return nil
//                }
//            }
//        }
//    }
//}
//
//enum BookCategory: Identifiable {
//    case custom(CategoryAnalytics)
//    
//    var id: String {
//        switch self {
//        case .custom(let category):
//            return category.id ?? ""
//        }
//    }
//    
//    var displayName: String {
//        switch self {
//        case .custom(let category):
//            return category.name
//        }
//    }
//}
//
