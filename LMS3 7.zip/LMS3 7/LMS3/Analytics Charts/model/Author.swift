//
//  Author.swift
//  BookstoreStategist
//
//  Created by Karin Prater on 16.07.23.
//

import Foundation

struct Author: Identifiable {
    let id: UUID = UUID()
    let name: String
    
    static var example = Author(name: "George R. R. Martin")
    
    static var examples = [
        Author(name: "J.K. Rowling"),
        Author(name: "George R. R. Martin"),
        Author(name: "J.R.R. Tolkien"),
        Author(name: "Agatha Christie"),
        Author(name: "Stephen King"),
        Author(name: "Dan Brown"),
        Author(name: "Harper Lee"),
        Author(name: "Jane Austen"),
        Author(name: "F. Scott Fitzgerald"),
        Author(name: "Ernest Hemingway")
    ]
}


//import Foundation
//import FirebaseFirestore
//
//struct Author: Identifiable {
//    let id: String // Firestore document ID
//    let name: String
//    
//    // Initialize from a Firestore document
//    init(id: String, name: String) {
//        self.id = id
//        self.name = name
//    }
//    
//    // Fetch authors from Firestore
//    static func fetchAuthorsFromFirestore(completion: @escaping ([Author]) -> Void) {
//        let db = Firestore.firestore()
//        let booksCollection = db.collection("books")
//        
//        booksCollection.getDocuments { (snapshot, error) in
//            guard let snapshot = snapshot, error == nil else {
//                print("Error fetching documents: \(error!)")
//                completion([])
//                return
//            }
//            
//            let authors = snapshot.documents.flatMap { document -> [Author] in
//                guard let authorNames = document.data()["authors"] as? [String] else {
//                    return []
//                }
//                // Map each author name to an Author instance
//                return authorNames.map { Author(id: document.documentID, name: $0) }
//            }
//            
//            completion(authors)
//        }
//    }
//    
//    // Example authors array (static for demonstration)
//    static var examples: [Author] = []
//    
//    // Fetch authors from Firestore and populate examples array
//    static func fetchAndPopulateExamples() {
//        fetchAuthorsFromFirestore { authors in
//            // Populate the examples array once data is fetched
//            examples = authors
//            print("Fetched authors: \(examples)")
//        }
//    }
//}
//
//// Call the function to fetch and populate examples array
////Author.fetchAndPopulateExamples()
