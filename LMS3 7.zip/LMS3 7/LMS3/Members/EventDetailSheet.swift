//
//  EventDetailSheet.swift
//  LMS3
//
//  Created by Aditya Majumdar on 09/05/24.
//

import SwiftUI
import Firebase
import FirebaseFirestore
import SDWebImageSwiftUI
import EventKit

struct EventDetailSheet: View {
    let eventRequest: EventRequest
    @State private var librarianComment = ""
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            VStack{
                if let url = URL(string: eventRequest.imageUrl) {
                    WebImage(url: url)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 280, height: 180)
                        .cornerRadius(10)
                }
                
                VStack(alignment: .leading, spacing: 3) {
                    Text(eventRequest.eventName)
                        .font(.headline)
                        .foregroundColor(.primary)
                    
                    Text("Date: \(eventRequest.eventDate, style: .date)")
                        .font(.subheadline)
                        .foregroundColor(Color(red: 228/255, green: 133/255, blue: 134/255))
                    
                    Text(eventRequest.eventDescription)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .lineLimit(4)
                    
                    HStack(spacing:50){
                        Text("Current Status: ")
                            .font(.headline)
                        statusBox(for: eventRequest.status)
                            .frame(width: 100, height: 30)
                    }
                    
                    Text("Librarian Comment:")
                        .font(.headline)
                        .padding(.top)
                    Text(librarianComment)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .lineLimit(nil)
                }
            }
            .frame(width:300)
            .padding()
            .overlay(RoundedRectangle(cornerRadius: 10)
                .stroke(Color.gray, lineWidth: 0.8))
            
        }.padding()
        .onAppear {
            fetchLibrarianComment()
        }
    }
    
    private func fetchLibrarianComment() {
        // Fetch librarian comment from Firestore
        let db = Firestore.firestore()
        
        // Query for the document based on eventName and memberID
        db.collection("eventRequests")
            .whereField("eventName", isEqualTo: eventRequest.eventName)
            .whereField("memberID", isEqualTo: eventRequest.memberID)
            .getDocuments { querySnapshot, error in
                if let error = error {
                    print("Error fetching librarian comment: \(error.localizedDescription)")
                    return
                }
                
                guard let documents = querySnapshot?.documents else {
                    print("No documents found")
                    return
                }
                
                // Assuming there's only one document that matches the query
                if let document = documents.first {
                    let data = document.data() ?? [:] // Provide a default empty dictionary in case data is nil
                    if let librarianComment = data["description"] as? String {
                        self.librarianComment = librarianComment
                    } else {
                        self.librarianComment = "N/A"
                        print("Librarian comment not found")
                    }
                } else {
                    print("Document does not exist")
                }
            }
    }
    

    
    private func statusBox(for status: EventStatus) -> some View {
        var color: Color
        var statusText: String
        
        switch status {
        case .pending:
            color = Color.yellow
            statusText = "Pending"
        case .accepted:
            color = Color.green
            statusText = "Accepted"
        case .rejected:
            color = Color.red
            statusText = "Rejected"
        }
        
        return Text(statusText)
            .foregroundColor(.white)
            .padding(5)
            .background(color)
            .cornerRadius(5)
            .padding(.leading, 5)
    }
}
