import SwiftUI
import Firebase
import FirebaseFirestore
import FirebaseFirestoreSwift
import FirebaseStorage

let db = Firestore.firestore()
let userCollectionRef = db.collection("Users")

struct Community: Identifiable, Codable {
    @DocumentID var id: String?
    var uid: String
    var username: String
    var text: String
    var timestamp: Timestamp
    var imageURL: String?
}

var userID: String {
    if let currentUser = Auth.auth().currentUser {
        return currentUser.uid
    } else {
        return ""
    }
}

func getUsername(forUID uid: String, completion: @escaping (String?) -> Void) {
    userCollectionRef.document(uid).getDocument { document, error in
        if let document = document, document.exists {
            if let data = document.data(), let username = data["name"] as? String {
                completion(username)
            } else {
                completion(nil)
            }
        } else {
            completion(nil)
        }
    }
}

class CommunityViewModel: ObservableObject {
    private var db = Firestore.firestore()
    
    @Published var communitys: [Community] = []
    
    init() {
        fetchCommunitys()
    }
    
    func fetchCommunitys() {
        db.collection("community").order(by: "timestamp", descending: true).addSnapshotListener { snapshot, error in
            guard let documents = snapshot?.documents else {
                print("Error fetching documents: \(error?.localizedDescription ?? "Unknown error")")
                return
            }
            self.communitys = documents.compactMap { document in
                do {
                    var community = try document.data(as: Community.self)
                    getUsername(forUID: community.uid) { username in
                        if let username = username {
                            community.username = username
                        }
                    }
                    return community
                } catch {
                    print("Error decoding community: \(error.localizedDescription)")
                    return nil
                }
            }
        }
    }
}

struct CommunityCloneView: View {
    @ObservedObject private var communityViewModel = CommunityViewModel()
    @State private var searchText = ""
    
    var filteredCommunity: [Community] {
        if searchText.isEmpty {
            return communityViewModel.communitys
        } else {
            return communityViewModel.communitys.filter { community in
                return community.text.lowercased().contains(searchText.lowercased()) ||
                    community.username.lowercased().contains(searchText.lowercased())
            }
        }
    }
    
    var body: some View {
        NavigationView {
            VStack {
                SearchBar(text: $searchText)
                    .padding(.horizontal)
                    .padding(.bottom)
                
                ScrollView {
                    if filteredCommunity.isEmpty {
                        Text("No posts found")
                            .foregroundColor(.gray)
                            .padding()
                    } else {
                        LazyVStack(spacing: 0) {
                            ForEach(filteredCommunity) { community in
                                CommunityView(community: community)
                                    .background(Color(UIColor.systemBackground))
                                    .cornerRadius(10)
                                    .shadow(color: Color(UIColor.systemGray3), radius: 5)
                                    .padding(.horizontal)
                                    .padding(.vertical, 8)
                            }
                        }
                        .padding(.top, 10)
                        .padding(.bottom, 70)
                    }
                }
                .overlay(
                    VStack {
                        Spacer()
                        HStack {
                            Spacer()
                            NavigationLink(destination: AddCommunityView()) {
                                Image(systemName: "square.and.pencil")
                                    .resizable()
                                    .frame(width: 30, height: 30)
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color(red: 228/255, green: 133/255, blue: 134/255))
                                    .clipShape(Circle())
                                    .shadow(radius: 4)
                            }
                            .padding(20)
                        }
                    }
                )
            }
            .navigationBarTitle("Community", displayMode: .inline)
            .navigationBarTitleDisplayMode(.inline)
            .onAppear {
                communityViewModel.fetchCommunitys()
            }
        }
    }
}

struct SearchBar: View {
    @Binding var text: String
    
    var body: some View {
        HStack {
            TextField("Search", text: $text)
                .padding(8)
                .background(Color(UIColor.systemGray5))
                .cornerRadius(10)
            
            if !text.isEmpty {
                Button(action: {
                    text = ""
                }) {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(.gray)
                        .padding(.trailing, 8)
                }
            }
        }
    }
}

struct CommunityView: View {
    var community: Community
    @State private var image: UIImage? = nil
    @State private var isLiked: Bool = false
    @State private var likes: Int = 0
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: "person.circle.fill")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 30, height: 30)
                    .clipShape(Circle())
                    .foregroundColor(.gray)
                
                VStack(alignment: .leading) {
                    Text(community.username)
                        .font(.headline)
                        .foregroundColor(.primary)
                    
                    Text("@\(community.username)")
                        .foregroundColor(.secondary)
                        .font(.subheadline)
                }
                
                Spacer()
            }
            .padding([.leading, .trailing, .top])
            
            Text(community.text)
                .padding([.leading, .trailing, .bottom])
                .foregroundColor(.primary)
            
            if let imageURL = community.imageURL, let url = URL(string: imageURL) {
                if let image = image {
                    Image(uiImage: image)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(maxHeight: 200)
                        .padding([.leading, .trailing])
                } else {
                    ProgressView()
                        .padding([.leading, .trailing])
                        .onAppear {
                            loadImage(from: url)
                        }
                }
            }
            
            HStack(spacing: 20) {
                Button(action: {
                    isLiked.toggle()
                    likes += isLiked ? 1 : -1
                }) {
                    Image(systemName: isLiked ? "heart.fill" : "heart")
                        .foregroundColor(isLiked ? .red : .secondary)
                }
                
                NavigationLink(destination: CommentView(communityID: community.id ?? "", userID: userID)) {
                    Image(systemName: "bubble.right")
                        .foregroundColor(.secondary)
                }
            }
            .padding(.leading)
            
            Text(timeAgo(from: community.timestamp.dateValue()))
                .foregroundColor(.secondary)
                .font(.footnote)
                .padding([.leading, .trailing])
                .padding(.bottom, 8)
        }
        .background(Color(UIColor.systemBackground))
    }
    
    private func timeAgo(from date: Date) -> String {
        let formatter = RelativeDateTimeFormatter()
        formatter.unitsStyle = .abbreviated
        return formatter.localizedString(for: date, relativeTo: Date()) // Correct method call
    }

    
    private func loadImage(from url: URL) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else {
                if let error = error {
                    print("Error fetching image: \(error)")
                } else {
                    print("Unknown error fetching image")
                }
                return
            }
            
            if let uiImage = UIImage(data: data) {
                DispatchQueue.main.async {
                    self.image = uiImage
                }
            }
        }.resume()
    }
}

struct CommunityCloneView_Previews: PreviewProvider {
    static var previews: some View {
        CommunityCloneView()
            .preferredColorScheme(.light)
        CommunityCloneView()
            .preferredColorScheme(.dark)
    }
}
