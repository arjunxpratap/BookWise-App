//
//  GenreScreen.swift
//  LMS_SD
//
//  Created by Sarthak Marwah on 25/04/24.
//

import SwiftUI
import Firebase

struct GenreScreen: View {
    @State private var genres: [String] = []
    @State private var booksPerGenre: [String: [Book]] = [:]
    @State private var selectedBook: Book? = nil
    @State private var isShowingBookDetail = false
    @State private var searchText = ""
    
    let db = Firestore.firestore()
    
    var body: some View {
        NavigationView {
            VStack {
                Text("Search")
                    .font(.largeTitle)
                    .bold()
                    .padding(.top)
                    .padding(.bottom)
                
                VStack (spacing: 20) {
                    
                    RoundedRectangle(cornerRadius: 10)
                        .foregroundColor(Color(red: 0.904, green: 0.904, blue: 0.904))
                        .opacity(0.6)
                        .frame(height: 35)
                        .overlay(
                            HStack {
                                Image(systemName: "magnifyingglass")
                                    .foregroundColor(.black)
                                TextField("Books, Authors, Genres and More", text: $searchText)
                                    
//                                Image(systemName: "mic")
//                                    .foregroundColor(.black) // Dark black
                            }
                            .padding(.horizontal)
                        )
                        .padding(.horizontal)
                        .padding(.bottom)
                }
                
                ScrollView {
                    
                    VStack(spacing: 20) {
                        ForEach(genres, id: \.self) { genre in
                            if let books = booksPerGenre[genre] {
                                GenreSection(genre: genre, books: filteredBooks(for: genre), didSelectBook: { book in
                                    self.selectedBook = book
                                    self.isShowingBookDetail = true
                                }, searchText: searchText)

                            }
                        }
                        Spacer()
                    }
                    .onAppear {
                        fetchGenres()
                    }
                }
            }
            .navigationBarHidden(true)
        }
    }
    
    private func filteredBooks(for genre: String) -> [Book] {
        guard let books = booksPerGenre[genre] else {
            return []
        }
        if searchText.isEmpty {
            return books
        } else {
            return books.filter { book in
                // Filter books based on search query
                let searchTextLowercased = searchText.lowercased()
                return book.title.lowercased().contains(searchTextLowercased) ||
                       book.authors.joined(separator: " ").lowercased().contains(searchTextLowercased) ||
                       book.genre.lowercased().contains(searchTextLowercased) ||
                       book.selectedCategory.lowercased().contains(searchTextLowercased) ||
                       book.publicationDate.lowercased().contains(searchTextLowercased) ||
                       book.publisher.lowercased().contains(searchTextLowercased)
            }
        }
    }
    
    func fetchGenres() {
        db.collection("categories").getDocuments { querySnapshot, error in
            if let error = error {
                print("Error fetching genres: \(error)")
                return
            }
            
            self.genres = querySnapshot?.documents.compactMap { $0.data()["name"] as? String } ?? []
            
            for genre in self.genres {
                self.fetchBooks(for: genre)
            }
        }
    }
    
    func fetchBooks(for genre: String) {
        db.collection("books").whereField("selectedCategory", isEqualTo: genre).getDocuments { querySnapshot, error in
            if let error = error {
                print("Error fetching books for \(genre): \(error)")
                return
            }
            
            let books = querySnapshot?.documents.compactMap { document -> Book? in
                let data = document.data()
                return Book(
                    id: document.documentID,
                    title: data["title"] as? String ?? "",
                    description: data["description"] as? String ?? "",
                    edition: data["edition"] as? String ?? "",
                    genre: data["genre"] as? String ?? "",
                    selectedCategory: data["selectedCategory"] as? String ?? "",
                    quantity: data["quantity"] as? Int ?? 0,
                    availability: data["availability"] as? Int ?? 0,
                    publicationDate: data["publicationDate"] as? String ?? "",
                    publisher: data["publisher"] as? String ?? "",
                    authors: data["authors"] as? [String] ?? [],
                    imageUrl: data["imageUrl"] as? String ?? "",
                    price: data["price"] as? Double ?? 0,
                    shelfNumber: data["shelfNumber"] as? String ?? ""
                )
            } ?? []
            
            DispatchQueue.main.async {
                self.booksPerGenre[genre] = books
            }
        }
    }
}

struct GenreSection: View {
    let genre: String
    let books: [Book]
    let didSelectBook: (Book) -> Void
    let searchText: String // Add searchText as a parameter
    
        var filteredBooks: [Book] {
                if !searchText.isEmpty {
                    let searchTextLowercased = searchText.lowercased()
                    return books.filter { book in
                        return book.title.lowercased().contains(searchTextLowercased) ||
                               book.authors.joined(separator: " ").lowercased().contains(searchTextLowercased) ||
                               book.genre.lowercased().contains(searchTextLowercased) ||
                               book.selectedCategory.lowercased().contains(searchTextLowercased) ||
                               book.publicationDate.lowercased().contains(searchTextLowercased) ||
                               book.publisher.lowercased().contains(searchTextLowercased)
                    }
                } else {
                    return books
                }
            }

    var body: some View {
        VStack(alignment: .leading) {
            if !filteredBooks.isEmpty {
                HStack(alignment: .center) {
                    Text("\(genre)")
                        .font(.title2)
                        .fontWeight(.bold)
                        .padding(.leading)
                }

                ScrollView(.horizontal, showsIndicators: false) {
                    LazyHGrid(rows: [GridItem(.fixed(160))], spacing: 10) {
                        ForEach(filteredBooks) { book in
                            BookImageView(book: book, didSelectBook: didSelectBook)
                        }
                    }
                    .padding(.horizontal)
                }
            }
        }
    }
}


struct BookImageView: View {
    let book: Book
    let didSelectBook: (Book) -> Void
    
    var body: some View {
        
        NavigationLink(destination: BookDetailViewMember(book: book)) {
            LoadableImageView(urlString: book.imageUrl) { _ in
            }
            .frame(width: 160, height: 240)
            .aspectRatio(contentMode: .fit)
            .cornerRadius(5)
        }
    }
}

// LoadableImageView to load images from URL and provide book info
struct LoadableImageView: View {
    let urlString: String
    let didFinishLoading: (LoadedImage) -> Void // Closure to handle image loading completion

    @State private var image: UIImage?
    @State private var isLoading = true
    @State private var loadedImage: LoadedImage?

    var body: some View {
        Group {
            if let image = image {
                Image(uiImage: image)
                    .resizable()
            } else {
                if isLoading {
                    ProgressView()
                } else {
                    Image(systemName: "photo")
                }
            }
        }
        .onAppear {
            loadImage()
        }

    }

    private func loadImage() {
        guard let url = URL(string: urlString) else {
            print("Invalid URL")
            isLoading = false
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else {
                print("Failed to load image: \(error?.localizedDescription ?? "Unknown error")")
                isLoading = false
                return
            }

            DispatchQueue.main.async {
                self.image = UIImage(data: data)
                isLoading = false
                loadedImage = LoadedImage(image: image, book: nil)
            }
        }.resume()
    }
}

struct LoadedImage {
    let image: UIImage?
    let book: Book?
}

struct GenreScreen_Previews: PreviewProvider {
    static var previews: some View {
        GenreScreen()
    }
}

