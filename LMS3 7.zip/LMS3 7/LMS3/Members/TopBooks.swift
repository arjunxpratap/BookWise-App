//
//  net.swift
//  new
//
//  Created by Aditya Majumdar on 07/05/24.
//

import SwiftUI
import Firebase
import SDWebImageSwiftUI

struct Net: View {
    @State private var booksWithRatings: [(book: Book, averageRating: Double)] = []
    @State private var topPicks: [Book] = []
    
    private let db = Firestore.firestore()
    
    private func fetchBooks() {
        // Fetching top rated books
        db.collection("books")
            .getDocuments { snapshot, error in
                // Handle error
                guard let documents = snapshot?.documents else { return }
                var fetchedBooks: [Book] = []
                for document in documents {
                    let data = document.data()
                    let isbn = data["isbn"] as? String ?? ""
                    let title = data["title"] as? String ?? ""
                    let description = data["description"] as? String ?? ""
                    let edition = data["edition"] as? String ?? ""
                    let genre = data["genre"] as? String ?? ""
                    let selectedCategory = data["selectedCategory"] as? String ?? ""
                    let quantity = data["quantity"] as? Int ?? 0
                    let availability = data["availability"] as? Int ?? 0
                    let publicationDate = data["publicationDate"] as? String ?? ""
                    let publisher = data["publisher"] as? String ?? ""
                    let authors = data["authors"] as? [String] ?? []
                    let imageUrl = data["imageUrl"] as? String ?? ""
                    let price = data["price"] as? Double ?? 0.0
                    let shelfNumber = data["shelfNumber"] as? String ?? ""
                    let book = Book(id: isbn, title: title, description: description, edition: edition, genre: genre, selectedCategory: selectedCategory, quantity: quantity, availability: availability, publicationDate: publicationDate, publisher: publisher, authors: authors, imageUrl: imageUrl, price: price, shelfNumber: shelfNumber)
                    fetchedBooks.append(book)
                }
                self.fetchBookRatings(for: fetchedBooks)
            }
        
        // Fetching top picks for the current user
        // Replace `currentUserID` with your logic to get the current user's ID
        guard let currentUserID = Auth.auth().currentUser?.uid else { return }
        
        db.collection("checkindetails")
            .whereField("memberID", isEqualTo: currentUserID)
            .getDocuments { snapshot, error in
                // Handle error
                guard let documents = snapshot?.documents else { return }
                var bookISBNs: [String] = []
                for document in documents {
                    let bookISBN = document["bookISBN"] as? String ?? ""
                    bookISBNs.append(bookISBN)
                }
                
                // Fetch books based on bookISBNs
                self.fetchBooksForISBNs(bookISBNs)
            }
    }
    
    private func fetchBooksForISBNs(_ bookISBNs: [String]) {
        for isbn in bookISBNs {
            db.collection("books")
                .whereField("isbn", isEqualTo: isbn)
                .getDocuments { snapshot, error in
                    // Handle error
                    guard let documents = snapshot?.documents else { return }
                    for document in documents {
                        let authors = document["authors"] as? [String] ?? []
                        let selectedCategory = document["selectedCategory"] as? String ?? ""
                        // Fetch books with same authors and selectedCategory
                        db.collection("books")
                            .whereField("authors", arrayContainsAny: authors)
                            .whereField("selectedCategory", isEqualTo: selectedCategory)
                            .getDocuments { snapshot, error in
                                // Handle error
                                guard let documents = snapshot?.documents else { return }
                                for document in documents {
                                    let data = document.data()
                                    let isbn = data["isbn"] as? String ?? ""
                                    let title = data["title"] as? String ?? ""
                                    let description = data["description"] as? String ?? ""
                                    let edition = data["edition"] as? String ?? ""
                                    let genre = data["genre"] as? String ?? ""
                                    let selectedCategory = data["selectedCategory"] as? String ?? ""
                                    let quantity = data["quantity"] as? Int ?? 0
                                    let availability = data["availability"] as? Int ?? 0
                                    let publicationDate = data["publicationDate"] as? String ?? ""
                                    let publisher = data["publisher"] as? String ?? ""
                                    let authors = data["authors"] as? [String] ?? []
                                    let imageUrl = data["imageUrl"] as? String ?? ""
                                    let price = data["price"] as? Double ?? 0.0
                                    let shelfNumber = data["shelfNumber"] as? String ?? ""
                                    let book = Book(id: isbn, title: title, description: description, edition: edition, genre: genre, selectedCategory: selectedCategory, quantity: quantity, availability: availability, publicationDate: publicationDate, publisher: publisher, authors: authors, imageUrl: imageUrl, price: price, shelfNumber: shelfNumber)
                                    self.topPicks.append(book)
                                }
                            }
                    }
                }
        }
}


    
    private func fetchBookRatings(for books: [Book]) {
        var booksWithRatings: [(book: Book, averageRating: Double)] = []
        
        for book in books {
            let bookRatingRef = db.collection("BookRating").document(book.id)
            
            bookRatingRef.getDocument { document, error in
                guard let document = document, document.exists else {
                    print("BookRating document does not exist for book ID: \(book.id)")
                    // If the document doesn't exist, consider the average rating as 0
                    booksWithRatings.append((book, 0))
                    // Check if ratings are fetched for all books
                    if booksWithRatings.count == books.count {
                        // Sort books with ratings by average rating in descending order
                        self.booksWithRatings = booksWithRatings.sorted { $0.averageRating > $1.averageRating }
                    }
                    return
                }
                
                if let ratings = document.data()?["ratings"] as? [Double] {
                    let total = ratings.count
                    let sum = ratings.reduce(0, +)
                    let averageRating = total > 0 ? sum / Double(total) : 0
                    booksWithRatings.append((book, averageRating))
                    
                    // Check if ratings are fetched for all books
                    if booksWithRatings.count == books.count {
                        // Sort books with ratings by average rating in descending order
                        self.booksWithRatings = booksWithRatings.sorted { $0.averageRating > $1.averageRating }
                    }
                }
            }
        }
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text("Top Rated Books")
                .font(.largeTitle).bold()
                .padding(.bottom, 10)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 25) {
                    ForEach(booksWithRatings.indices, id: \.self) { index in
                        HStack(spacing: -40) {
                            Text("\(index + 1)") // Display the number
                                .font(
                                    Font.custom("Inter", size: 160)
                                    .weight(.heavy)
                                )
                                .font(.largeTitle)
                                .foregroundStyle(Color.black)
                            NavigationLink(destination: BookDetailViewMember(book: booksWithRatings[index].book)) {
                                VStack{
                                    WebImage(url: URL(string: booksWithRatings[index].book.imageUrl))
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 140, height: 200)
                                        .cornerRadius(10)
                                        .shadow(radius: 5)
                                }
                            }
                        }
                    }
                }
                .padding(.leading, -10)
            }
            
            Text("Top Picks for You")
                .font(.largeTitle).bold()
                .padding(.bottom, 10)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 25) {
                    ForEach(topPicks.indices, id: \.self) { index in
                        HStack(spacing: -40) {
                            Text("\(index + 1)") // Display the number
                                .font(
                                    Font.custom("Inter", size: 160)
                                    .weight(.heavy)
                                )
                                .font(.largeTitle)
                                .foregroundStyle(Color.black)
                            NavigationLink(destination: BookDetailViewMember(book: topPicks[index])) {
                                VStack{
                                    WebImage(url: URL(string: topPicks[index].imageUrl))
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 140, height: 200)
                                        .cornerRadius(10)
                                        .shadow(radius: 5)
                                }
                            }
                        }
                    }
                }
                .padding(.leading, -10)
            }
        }
        .padding(.leading)
        .onAppear {
            fetchBooks()
        }
    }
}

#if DEBUG
struct Net_Previews: PreviewProvider {
    static var previews: some View {
        Net()
    }
}
#endif
