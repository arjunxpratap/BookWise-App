//
//  BorrowingHistory.swift
//  LMS3
//
//  Created by Aditya Majumdar on 25/04/24.
//

import SwiftUI
import FirebaseFirestore
import FirebaseAuth

struct BookInfo: Identifiable {
    let id = UUID()
    let isbn: String
    let title: String
    let author: [String]
    let imageUrl: String
    let issueDate: String
    let returnDate: String?
    let dueDate: String
}

struct BorrowingHistoryView: View {
    @State private var currentIssues: [BookInfo] = []
    @State private var returnedBooks: [BookInfo] = []
    
    private let db = Firestore.firestore()
    private var uid: String?
    
    init() {
        if let currentUser = Auth.auth().currentUser {
            uid = currentUser.uid
        }
    }
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment:.leading){
                    // Current Issues
                    if !currentIssues.isEmpty {
                        VStack(alignment: .leading) {
                            Text("Current Issue")
                                .font(.headline)
                                .padding(.bottom)
                            ForEach(currentIssues) { book in
                                BookItemView(book: book, rating: self.getRating(for: book))
                            }
                        }
                        .padding(.vertical)
                    }
                    
                    // Returned Books
                    if !returnedBooks.isEmpty {
                        VStack(alignment: .leading) {
                            Text("Returned")
                                .font(.headline)
                                .padding(.bottom)
                            ForEach(returnedBooks) { book in
                                BookItemView(book: book, rating: self.getRating(for: book))
                            }
                        }
                        .padding(.vertical)
                    }
                }
                .navigationTitle("Borrowing History")
            }
            .onAppear {
                if let uid = uid {
                    fetchBooks(uid: uid)
                }
            }
        }
    }
    
    private func fetchBooks(uid: String) {
        currentIssues.removeAll()
        returnedBooks.removeAll()
        db.collection("checkindetails")
            .whereField("memberID", isEqualTo: uid)
            .whereField("ifcheckout", isEqualTo: "NO")
            .getDocuments { querySnapshot, error in
                guard let documents = querySnapshot?.documents else {
                    print("Error fetching current issues: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }
                for document in documents {
                    let data = document.data()
                    let bookISBN = data["bookISBN"] as? String ?? ""
                    let issueDate = data["checkInDate"] as? String ?? ""
                    
                    // Convert issueDate string to Date
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "dd/MM/yyyy"
                    if let issueDateFormatted = dateFormatter.date(from: issueDate) {
                        // Calculate dueDate by adding 7 days
                        let dueDate = Calendar.current.date(byAdding: .day, value: 7, to: issueDateFormatted)!
                        
                        // Convert dates to "dd/MM/yyyy" format
                        let issueDateString = dateFormatter.string(from: issueDateFormatted)
                        let dueDateString = dateFormatter.string(from: dueDate)
                        
                        // Now you can proceed to fetch book info with bookISBN, issueDateString, and dueDateString
                        fetchBookInfo(bookISBN: bookISBN, issueDate: issueDateString, dueDate: dueDateString)
                    } else {
                        print("Error parsing issue date")
                    }
                }
            }
        
        db.collection("checkoutdetail")
            .whereField("memberID", isEqualTo: uid)
            .getDocuments { querySnapshot, error in
                guard let documents = querySnapshot?.documents else {
                    print("Error fetching returned books: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }
                for document in documents {
                    let data = document.data()
                    let bookISBN = data["bookISBN"] as? String ?? ""
                    let issueDate = data["checkInDate"] as? String ?? ""
                    let dueDate = data["dueDate"] as? String ?? ""
                    let returnDate = data["returnDate"] as? String ?? ""
                    fetchBookInfo(bookISBN: bookISBN, issueDate: issueDate, returnDate: returnDate, dueDate: dueDate)
                }
            }
    }
    
    private func fetchBookInfo(bookISBN: String, issueDate: String, dueDate: String) {
        db.collection("books")
            .whereField("isbn", isEqualTo: bookISBN) // Match by ISBN
            .getDocuments { querySnapshot, error in
                guard let documents = querySnapshot?.documents else {
                    print("Error fetching book info: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }
                
                for document in documents {
                    let data = document.data()
                    let title = data["title"] as? String ?? ""
                    let author = data["authors"] as? [String] ?? []
                    let imageUrl = data["imageUrl"] as? String ?? ""
                    let isbn = data["isbn"] as? String ?? ""
                    let bookInfo = BookInfo(isbn: isbn, title: title, author: author, imageUrl: imageUrl, issueDate: issueDate, returnDate: nil, dueDate: dueDate)
                    
                    currentIssues.append(bookInfo)
                }
            }
    }
    
    private func fetchBookInfo(bookISBN: String, issueDate: String, returnDate: String, dueDate: String) {
        db.collection("books")
            .whereField("isbn", isEqualTo: bookISBN) // Match by ISBN
            .getDocuments { querySnapshot, error in
                guard let documents = querySnapshot?.documents else {
                    print("Error fetching book info: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }
                
                for document in documents {
                    let data = document.data()
                    let isbn = data["isbn"] as? String ?? ""
                    let title = data["title"] as? String ?? ""
                    let author = data["authors"] as? [String] ?? []
                    let imageUrl = data["imageUrl"] as? String ?? ""
                    let bookInfo = BookInfo(isbn: isbn, title: title, author: author, imageUrl: imageUrl, issueDate: issueDate, returnDate: returnDate, dueDate: dueDate)
                    
                    returnedBooks.append(bookInfo)
                }
            }
    }
    
    private func getRating(for book: BookInfo) -> Int {
        // Fetch the rating for this book from Firestore based on the user's ID and book ID
        // For now, return a default rating of 0
        return 0
    }
    
    private func updateRating(for book: BookInfo, rating: Int) {
        // Update the rating for this book in Firestore
        if let uid = uid {
            // Update MemberRating collection
            let memberRatingRef = db.collection("MemberRating").document(uid)
            memberRatingRef.setData(["\(book.isbn)": rating], merge: true)
            
            // Update BookRating collection
            let bookRatingRef = db.collection("BookRating").document(book.isbn)
            bookRatingRef.updateData(["ratings": FieldValue.arrayUnion([rating])])
        }
    }
}

struct BookItemView: View {
    let book: BookInfo
    @State private var bookImage: UIImage?
    @State  var rating: Int
    
    var body: some View {
        VStack(alignment: .leading) {
            HStack(spacing:50){
                if let image = bookImage {
                    Image(uiImage: image)
                        .resizable()
                        .frame(width: 120, height: 180)
                        .cornerRadius(5.0)
                } else {
                    ProgressView()
                        .frame(width: 120, height: 180)
                        .cornerRadius(5.0)
                }
                VStack(alignment: .leading) {
                    Text(book.title)
                        .foregroundStyle((Color(red: 228/255, green: 133/255, blue: 134/255))).bold()
                        .font(.headline)
    
                    if book.author.count > 1 {
                        ForEach(book.author, id: \.self) { author in
                            Text(author)
                                .font(.subheadline)
                                .foregroundStyle(Color.gray)
                        }
                    } else {
                        Text(book.author.first ?? "")
                            .font(.subheadline)
                            .foregroundStyle(Color.gray)
                    }
//                    ZStack{
//                        Rectangle()
//                            .cornerRadius(5.0)
//                            .frame(width:60,height: 30)
//                            .foregroundColor((Color(red: 228/255, green: 133/255, blue: 134/255)))
//                        Text("₹500")
//                            .font(.subheadline)
//                    }
                    
                    VStack(alignment:.leading,spacing:-5.5){
                        HStack{
                            Circle()
                                .frame(width: 10, height:10)
                            Text(" \(book.issueDate)")
                                .font(.subheadline)
                        }
                        Rectangle()
                            .strokeBorder(lineWidth: 1)
                            .fill(Color.gray)
                            .frame(width: 1, height: 25)
                            .padding(.leading,4.5)
                        if let returnDate = book.returnDate {
                            HStack{
                                Circle()
                                
                                    .fill(Color.green)
                                    .frame(width: 10, height:10)
                                Text(" \(returnDate)")
                                    .font(.subheadline)
                            }
                        }
                        else{
                            HStack{
                                Circle()
                                    .fill(Color.red)
                                    .frame(width: 10, height:10)
                                Text(" \(book.dueDate)")
                                    .font(.subheadline)
                            }
                        }
                    }
                }
                .padding(.leading, 10)
            }
            HStack {
                Text("Rate the Book:")
                    .font(.subheadline)
                HStack(spacing:2){
                    ForEach(1...5, id: \.self) { index in
                        Image(systemName: index <= self.rating ? "star.fill" : "star")
                            .foregroundColor((Color(red: 228/255, green: 133/255, blue: 134/255)))
                            .onTapGesture {
                                self.rating = index
                                self.updateRating()
                            }
                    }
                }
            }
            .padding(.bottom, 10)
        }.frame(width:340,alignment: .leading)
            .onAppear {
                loadImage()
                fetchRating()
            }
    }
    
    private func fetchRating() {
        if let uid = Auth.auth().currentUser?.uid {
            let memberRatingRef = db.collection("MemberRating").document(uid)
            memberRatingRef.getDocument { document, error in
                if let document = document, document.exists {
                    let data = document.data()!
                    if let rating = data[self.book.isbn] as? Int {
                        self.rating = rating
                    }
                } else {
                    print("MemberRating document does not exist")
                }
            }
        }
    }
    
    private func loadImage() {
        guard let imageUrl = URL(string: book.imageUrl) else { return }
        
        URLSession.shared.dataTask(with: imageUrl) { data, response, error in
            guard let data = data, error == nil else {
                if let error = error {
                    print("Error fetching image: \(error)")
                } else {
                    print("Unknown error fetching image")
                }
                return
            }
            
            DispatchQueue.main.async {
                self.bookImage = UIImage(data: data)
            }
        }.resume()
    }
    
    
    private func updateRating() {
        if let uid = Auth.auth().currentUser?.uid {
            // Update MemberRating
            let memberRatingRef = db.collection("MemberRating").document(uid)
            memberRatingRef.setData([self.book.isbn: self.rating], merge: true) { error in
                if let error = error {
                    print("Error updating MemberRating: \(error.localizedDescription)")
                } else {
                    print("Rating updated successfully")
                }
            }
            
            // Update BookRating
            let bookRatingRef = db.collection("BookRating").document(self.book.isbn)
            bookRatingRef.getDocument { document, error in
                if let document = document, document.exists {
                    // Document exists, update the ratings array
                    bookRatingRef.updateData(["ratings": FieldValue.arrayUnion([self.rating])]) { error in
                        if let error = error {
                            print("Error updating BookRating: \(error.localizedDescription)")
                        } else {
                            print("BookRating updated successfully")
                        }
                    }
                } else {
                    // Document does not exist, create a new document with ratings array
                    bookRatingRef.setData(["ratings": [self.rating]]) { error in
                        if let error = error {
                            print("Error creating BookRating document: \(error.localizedDescription)")
                        } else {
                            print("New BookRating document created with initial rating")
                        }
                    }
                }
            }
        }
    }
}

struct RemoteImage: View {
    private let url: String
    @StateObject private var imageLoader = ImageLoaderBorrowing()
    
    init(url: String) {
        self.url = url
        self.imageLoader.loadImage(from: url)
    }
    
    var body: some View {
        if let imageData = imageLoader.downloadedImageData, let uiImage = UIImage(data: imageData) {
            Image(uiImage: uiImage)
                .resizable()
        } else {
            ProgressView()
        }
    }
}


class ImageLoaderBorrowing: ObservableObject {
    @Published var downloadedImageData: Data?
    
    func loadImage(from url: String) {
        guard let imageURL = URL(string: url) else { return }
        URLSession.shared.dataTask(with: imageURL) { data, _, error in
            guard let data = data, error == nil else { return }
            DispatchQueue.main.async {
                self.downloadedImageData = data
            }
        }.resume()
    }
}


struct BorrowingHistoryView_Previews: PreviewProvider {
    static var previews: some View {
        BorrowingHistoryView()
    }
}
