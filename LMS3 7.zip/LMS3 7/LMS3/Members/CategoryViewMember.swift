//
//  CategoryViewMember.swift
//  LMS3
//
//  Created by Aditya Majumdar on 26/04/24.
//

import SwiftUI
import SDWebImageSwiftUI
import Firebase
import FirebaseFirestore
import FirebaseFirestoreSwift
import FirebaseStorage


struct CategoryDetailViewMemeber: View {
    let category: Category
    @State private var books: [Book] = []
    @State private var selectedBook: Book?
    @State private var isBookDetailViewPresented = false
    private let db = Firestore.firestore()
    
    var body: some View {
        VStack {
            HStack{
                Text(category.name)
                    .font(.largeTitle).bold()
                    .padding()
                
                Spacer()
                
                
            }
            if books.isEmpty {
                Text("No Books Found")
                    .padding()
            }
            else {
                List {
                    ForEach(books) { book in
                        NavigationLink(destination: BookDetailViewMember(book: book)){
                            BookRowViewMember(book: book)
                        }
                    }
                }
                .listStyle(PlainListStyle())
            }
            Spacer()
        }
        .onAppear {
                        fetchBooks()
                    }
                }
    
    private func fetchBooks() {
        db.collection("books")
            .whereField("selectedCategory", isEqualTo: category.name)
            .addSnapshotListener { querySnapshot, error in
                if let error = error {
                    print("Error fetching books: \(error.localizedDescription)")
                    return
                }

                guard let documents = querySnapshot?.documents else {
                    print("No books found")
                    return
                }

                books = documents.compactMap { queryDocumentSnapshot -> Book? in
                    do {
                        // Attempt to decode Firestore document into a Book model
                        let book = try queryDocumentSnapshot.data(as: Book.self)
                        return book
                    } catch {
                        print("Error decoding book: \(error.localizedDescription)")
                        return nil
                    }
                }
            }
    }

}


struct BookRowViewMember: View {
    let book: Book
    @State private var image: UIImage? = nil

    var body: some View {
        HStack {
            if let image = image {
                Image(uiImage: image)
                    .resizable()
                    .frame(width: 60, height: 60)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .padding(.trailing)
            } else {
                Image(systemName: "photo")
                    .resizable()
                    .frame(width: 60, height: 60)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .padding(.trailing)
            }

            VStack(alignment: .leading) {
                Text(book.title)
                    .font(.headline)
                Text(book.authors.joined(separator: ", "))
                    .font(.subheadline)
            }

            Spacer()
            
        }
        .onAppear {
            loadImage()
        }
        .frame(height: 100)
        .cornerRadius(15)
    }

    private func loadImage() {
        guard let imageUrl = URL(string: book.imageUrl) else { return }
        
        URLSession.shared.dataTask(with: imageUrl) { data, response, error in
            guard let data = data, error == nil else {
                if let error = error {
                    print("Error fetching image: \(error)")
                } else {
                    print("Unknown error fetching image")
                }
                return
            }
            
            DispatchQueue.main.async {
                self.image = UIImage(data: data)
            }
        }.resume()
    }
}
