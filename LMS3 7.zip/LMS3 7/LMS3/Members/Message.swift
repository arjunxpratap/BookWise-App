import SwiftUI
import Firebase
import FirebaseStorage
import FirebaseFirestore
import UIKit

struct AddCommunityView: View {
    @State private var communityText: String = ""
    @State private var selectedImage: UIImage?
    @State private var isImagePickerPresented = false
    @State private var username: String?
    @Environment(\.presentationMode) var presentationMode

    private var db = Firestore.firestore()
    private var storage = Storage.storage().reference()
    private var uid: String

    init() {
        self.uid = Auth.auth().currentUser?.uid ?? ""
        fetchUsername()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            ScrollView {
                Text("Send a Message")
                    .font(.title)
                    .foregroundColor(Color.primary)
                    .padding()

                if let username = username {
                    Text("Welcome, \(username)!")
                        .font(.headline)
                        .foregroundColor(Color.secondary)
                        .padding()
                }

                TextField("Type your message", text: $communityText)
                    .padding()
                    .background(Color(UIColor.secondarySystemBackground))
                    .cornerRadius(10)
                    .padding()

                Button(action: {
                    isImagePickerPresented.toggle()
                }) {
                    HStack {
                        Image(systemName: "photo")
                        Text("Select Image")
                    }
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color(red: 228/255, green: 133/255, blue: 134/255))
                    .cornerRadius(10)
                }
                .padding()

                if let selectedImage = selectedImage {
                    Image(uiImage: selectedImage)
                        .resizable()
                        .scaledToFit()
                        .frame(maxWidth: .infinity, maxHeight: 200)
                        .padding()
                }

                Button(action: {
                    postCommunity()
                }) {
                    Text("Post")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color(red: 228/255, green: 133/255, blue: 134/255))
                        .cornerRadius(10)
                }
                .padding()
            }
        }
        .sheet(isPresented: $isImagePickerPresented) {
            ImagePickerCommunity(image: $selectedImage)
        }
        .padding()
    }
    private func postCommunity() {
        guard !communityText.isEmpty else {
            return
        }

        if let image = selectedImage, let imageData = image.jpegData(compressionQuality: 0.5) {
            let imageFileName = UUID().uuidString
            let imageRef = storage.child("community_images/\(imageFileName)")

            let uploadTask = imageRef.putData(imageData, metadata: nil) { metadata, error in
                guard let metadata = metadata else {
                    print("Error uploading image to Firebase Storage: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }
                imageRef.downloadURL { url, error in
                    guard let downloadURL = url else {
                        print("Error retrieving download URL: \(error?.localizedDescription ?? "Unknown error")")
                        return
                    }
                    saveCommunity(imageURL: downloadURL.absoluteString)
                }
            }
            uploadTask.observe(.progress) { snapshot in
                let percentComplete = 100.0 * Double(snapshot.progress!.completedUnitCount) / Double(snapshot.progress!.totalUnitCount)
                print("Upload progress: \(percentComplete)%")
            }
        } else {
            saveCommunity(imageURL: nil)
        }
    }

    private func saveCommunity(imageURL: String?) {
        db.collection("Users").document(uid).getDocument { userDocument, error in
            if let userDocument = userDocument, userDocument.exists {
                if let username = userDocument["name"] as? String {
                    var communityData: [String: Any] = [
                        "uid": uid,
                        "username": username,
                        "text": communityText,
                        "timestamp": FieldValue.serverTimestamp()
                    ]
                    if let imageURL = imageURL {
                        communityData["imageURL"] = imageURL
                    }
                    db.collection("community").addDocument(data: communityData) { communityError in
                        if let communityError = communityError {
                            print("Error saving community to Firestore: \(communityError.localizedDescription)")
                        } else {
                            print("Community successfully saved to Firestore")
                            communityText = ""
                            selectedImage = nil // Clear selected image after posting
                            presentationMode.wrappedValue.dismiss()
                        }
                    }
                }
            } else {
                print("Error fetching username: \(error?.localizedDescription ?? "Unknown error")")
            }
        }
    }

    private func fetchUsername() {
        db.collection("Users").document(uid).getDocument { document, error in
            if let document = document, document.exists {
                if let username = document["name"] as? String {
                    self.username = username
                }
            } else {
                print("Error fetching username: \(error?.localizedDescription ?? "Unknown error")")
            }
        }
    }
}

struct AddCommunityView_Previews: PreviewProvider {
    static var previews: some View {
        AddCommunityView()
    }
}

struct ImagePickerCommunity: UIViewControllerRepresentable {
    @Binding var image: UIImage?

    func makeCoordinator() -> Coordinator {
        return Coordinator(parent:self)
    }

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        picker.sourceType = .photoLibrary
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}

    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let parent: ImagePickerCommunity

        init(parent: ImagePickerCommunity) {
            self.parent = parent
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let image = info[.originalImage] as? UIImage {
                parent.image = image
            }
            picker.dismiss(animated: true, completion: nil)
        }
    }
}
