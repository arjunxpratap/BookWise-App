//
//  SearchScreen.swift
//  LMS3
//
//  Created by Aditya Majumdar on 26/04/24.
//

import SwiftUI
import Firebase

struct Search: View {
    @State private var searchText = ""
    @State private var books: [Book] = []
    @State private var categories: [Category] = []
    @State private var isAccountScreenPresented = false
    private let db = Firestore.firestore()
    
    var body: some View {
        ScrollView {
            VStack(spacing: 30) {
                HStack {
                    Text("Home").font(.system(size: 28, weight: .bold))
                    Spacer()
                    Image(systemName: "person.circle")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 30, height: 30)
                                            .onTapGesture {
                                                isAccountScreenPresented = true
                                            }
                                    }
                .padding(.horizontal)

                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(Color(red: 0.904, green: 0.904, blue: 0.904)) // Light gray
                    .frame(height: 35)
                    .overlay(
                        HStack {
                            Image(systemName: "magnifyingglass")
                            TextField("Books, Authors, Genres and More", text: $searchText)
                                .foregroundColor(.black)
                            Image(systemName: "mic")
                                .foregroundColor(Color(red: 0.1176, green: 0.1216, blue: 0.1804)) // Dark black
                        }
                        .padding(.horizontal)
                    )

                if filteredBooks.isEmpty && !searchText.isEmpty {
                                    Text("No results found")
                                        .font(.headline)
                                        .foregroundColor(.black)
                                        .padding()
                                }
                else if searchText.isEmpty {
                    VStack(alignment: .leading, spacing: 15) {
                        Text("Top Genres").font(.system(size: 28, weight: .bold))
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 10) {
                                ForEach(categories) { category in
                                    NavigationLink(destination: CategoryDetailViewMemeber(category: category)) {
                                        GenreView(genreName: category.name, imageURL: category.imageUrl, lightGray: Color(red: 0.904, green: 0.904, blue: 0.904))
                                    }
                                }
                            }
                        }
                    }

                    VStack(alignment: .leading, spacing: 15) {
                        Text("Top Books").font(.system(size: 28, weight: .bold))
                            .foregroundColor(Color(red: 0.1176, green: 0.1216, blue: 0.1804)) // Dark black

                        ScrollView(.vertical) {
                            VStack(spacing: 10) {
                                ForEach(books) { book in
                                    NavigationLink(destination: BookDetailViewMember(book: book)) {
                                        BookRow(book: book)
                                    }
                                }
                            }
                        }
                        .frame(maxHeight: 300)
                    }
                } else {
                    VStack(alignment: .leading, spacing: 15) {
                        ForEach(filteredBooks) { book in
                            NavigationLink(destination: BookDetailViewMember(book: book)) {
                                BookRow(book: book)
                            }
                        }
                    }
                }
            }
            .padding()
            .background(
                            NavigationLink(
                                destination: Account_Screen(),
                                isActive: $isAccountScreenPresented
                            ) {
                                EmptyView()
                            }
                        )
                    }
        .onAppear {
            fetchCategories()
            fetchBooks()
        }
    }

    private func fetchCategories() {
        db.collection("categories")
            .getDocuments { snapshot, error in
                if let error = error {
                    print("Error fetching categories: \(error.localizedDescription)")
                    return
                }

                guard let documents = snapshot?.documents else {
                    print("No categories found")
                    return
                }

                categories = documents.compactMap { queryDocumentSnapshot -> Category? in
                    do {
                        // Attempt to decode Firestore document into a Category model
                        let category = try queryDocumentSnapshot.data(as: Category.self)
                        return category
                    } catch {
                        print("Error decoding category: \(error.localizedDescription)")
                        return nil
                    }
                }
            }
    }

    private func fetchBooks() {
        db.collection("books") // Assuming your collection is named "books"
            .getDocuments { snapshot, error in
                if let error = error {
                    print("Error fetching books: \(error.localizedDescription)")
                    return
                }

                guard let documents = snapshot?.documents else {
                    print("No books found")
                    return
                }

                books = documents.compactMap { queryDocumentSnapshot -> Book? in
                    do {
                        // Attempt to decode Firestore document into a Book model
                        let book = try queryDocumentSnapshot.data(as: Book.self)
                        return book
                    } catch {
                        print("Error decoding book: \(error.localizedDescription)")
                        return nil
                    }
                }
            }
    }

    private var filteredBooks: [Book] {
        if searchText.isEmpty {
            return books
        } else {
            return books.filter { book in
                // Filter books based on search query
                let searchTextLowercased = searchText.lowercased()
                return book.title.lowercased().contains(searchTextLowercased) ||
                       book.authors.joined(separator: " ").lowercased().contains(searchTextLowercased) ||
                       book.genre.lowercased().contains(searchTextLowercased) ||
                       book.selectedCategory.lowercased().contains(searchTextLowercased) ||
                       book.publicationDate.lowercased().contains(searchTextLowercased) ||
                       book.publisher.lowercased().contains(searchTextLowercased)
            }
        }
    }
}


struct BookRow: View {
    let book: Book
    @State private var image: UIImage?
    
    var body: some View {
        HStack {
            if let image = image {
                Image(uiImage: image)
                    .resizable()
                    .frame(width: 60, height: 60)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .padding(.trailing)
            } else {
                Image(systemName: "photo")
                    .resizable()
                    .frame(width: 60, height: 60)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .padding(.trailing)
                    .foregroundColor(.black)
            }

            VStack(alignment: .leading) {
                Text(book.title)
                    .font(.headline)
                    .foregroundColor(.black)
                Text(book.authors.joined(separator: ", "))
                    .font(.subheadline)
                    .foregroundColor(.black)
            }

            Spacer()
        }
        .onAppear {
            loadImage()
        }
        .frame(height: 100)
        .cornerRadius(15)
    }

    private func loadImage() {
        guard let imageUrl = URL(string: book.imageUrl) else { return }
        
        URLSession.shared.dataTask(with: imageUrl) { data, response, error in
            guard let data = data, error == nil else {
                if let error = error {
                    print("Error fetching image: \(error)")
                } else {
                    print("Unknown error fetching image")
                }
                return
            }
            
            DispatchQueue.main.async {
                self.image = UIImage(data: data)
            }
        }.resume()
    }
}

struct GenreView: View {
    var genreName: String
    var imageURL: String
    var lightGray: Color

    var body: some View {
        VStack {
            if let url = URL(string: imageURL), let data = try? Data(contentsOf: url), let uiImage = UIImage(data: data) {
                Image(uiImage: uiImage)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 103, height: 98)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                Text(genreName)
                    .font(.subheadline).bold()
                    .foregroundColor(.black)
            } else {
                Color.gray
                    .frame(width: 103, height: 98)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                Text(genreName)
                    .font(.caption)
                    .foregroundColor(.black)
            }
        }
    }
}



struct Search_Previews: PreviewProvider {
    static var previews: some View {
        Search()
    }
}
