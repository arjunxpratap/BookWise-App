//
//  BookDetailsMembers.swift
//  LMS3
//
//  Created by Aditya Majumdar on 26/04/24.
//

import SwiftUI
import SDWebImageSwiftUI
import Firebase
import FirebaseFirestore
import FirebaseFirestoreSwift
import FirebaseStorage

struct BookDetailViewMember: View {
    let book: Book
    @State private var selectedBook: Book?
    @State private var bookImage: UIImage? = nil
    @State private var isReserve = false
    @State private var averageRating: Double = 0
    @State private var totalRatings: Int = 0

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    Spacer()
                    if let image = bookImage {
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .frame(width: UIScreen.main.bounds.width * 0.55)
                            .cornerRadius(10)
                            .shadow(radius: 10)
                            .padding(.top)
                            .padding(.horizontal)
                    } else {
                        ProgressView()
                            .frame(width: UIScreen.main.bounds.width * 0.55, height: UIScreen.main.bounds.width * 0.55)
                            .padding(.top)
                    }
                    Spacer()
                }
                HStack {
                    Spacer()
                    Text(book.title)
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(Color(red: 228/255, green: 133/255, blue: 134/255))
                    Spacer()
                }
                
                HStack {
                    Spacer()
                    ForEach(0..<5) { index in
                        if index < Int(averageRating) {
                            Image(systemName: "star.fill")
                                .foregroundColor(Color(red: 228/255, green: 133/255, blue: 134/255))
                        } else if index == Int(averageRating) && averageRating.truncatingRemainder(dividingBy: 1) > 0 {
                            Image(systemName: "star.leadinghalf.fill")
                                .foregroundColor(Color(red: 228/255, green: 133/255, blue: 134/255))
                        } else {
                            Image(systemName: "star")
                                .foregroundColor(Color(red: 228/255, green: 133/255, blue: 134/255))
                        }
                    }
                    Spacer()
                    
                }
                HStack {
                    Spacer()
                        Text("(\(totalRatings) Ratings)")
                            .font(.subheadline)
                            .foregroundColor(Color.gray)
                            .padding(.top,-7)
                    Spacer()
                    }

                
                
                NavigationLink(destination: ReserveBookViewMember(bookTitle: book.title, bookImage: bookImage ?? UIImage()), isActive: $isReserve) {
                    EmptyView()
                }
                .hidden()
                
                Button(action: {
                    isReserve = true
                                }) {
                                    
                                    Text("Reserve")
                                        .font(.headline)
                                        .foregroundColor(.white)
                                        .padding()
                                        .frame(maxWidth: .infinity)
                                        .background((Color(red: 228/255, green: 133/255, blue: 134/255)))
                                        .cornerRadius(8)
                                        .padding(.horizontal)
                                }

                    VStack(alignment: .leading){
                            Text("Description:")
                                .font(.headline)

                        Text(book.description)
                            .padding()
//                            .background(Color(red: 240/255, green: 240/255, blue: 240/255))
                            .cornerRadius(8)
                            .foregroundColor(Color.primary)
                    }

                HStack {
                    VStack(alignment: .leading) {
                        Text("Author:")
                            .font(.headline)
                        Text("\(book.authors.joined(separator: ", "))")
                            .font(.headline)
                            .foregroundColor(Color(red: 228/255, green: 133/255, blue: 134/255))
                            .font(.headline)
                    }
                    
                    Spacer()
                    
                    VStack(alignment: .trailing) {
                        Text("Availability:")
                            .font(.headline)
                        Text("\(book.availability)")
                            .foregroundColor(Color(red: 228/255, green: 133/255, blue: 134/255))
                            .font(.headline)
                    }.padding(.trailing)
                    
                }
                HStack {
                    VStack(alignment: .leading) {
                        Text("Edition:")
                            .font(.headline)
                            Text(book.edition)
                                .foregroundColor(Color(red: 228/255, green: 133/255, blue: 134/255))
                                .font(.headline)
                        
                    }

                    Spacer()

                    VStack(alignment: .trailing) {
                        Text("Published on:")
                            .font(.headline)
                        Text(book.publicationDate)
                            .foregroundColor(Color(red: 228/255, green: 133/255, blue: 134/255))
                            .font(.headline)
                    }
                    .padding(.trailing)
                }
                HStack{
                    VStack(alignment: .leading) {
                        Text("Genre:")
                            .font(.headline)
                        Text(book.genre)
                            .font(.headline)
                            .foregroundColor(Color(red: 228/255, green: 133/255, blue: 134/255))
                    }
                    Spacer()
                    
                    VStack(alignment: .trailing) {
                        Text("Published by:")
                            .font(.headline)
                        Text(book.publisher)
                            .font(.headline)
                            .foregroundColor(Color(red: 228/255, green: 133/255, blue: 134/255))
                    }
                    .padding(.trailing)
                }
                
                HStack{
                    VStack(alignment: .leading) {
                        Text("Shelf number:")
                            .font(.headline)
                        Text(book.shelfNumber)
                            .font(.headline)
                            .foregroundColor(Color(red: 228/255, green: 133/255, blue: 134/255))
                    }
                    Spacer()
                }
                 
                //btn
            }
            .padding(.horizontal)
//            .background(
//                Image("book")
//                    .resizable()
//                    .opacity(0.04)
//                    .scaledToFill()
//                    .edgesIgnoringSafeArea(.all)
//            )
//            .background(Color(red: 245/255, green: 245/255, blue: 245/255))
        }
        .navigationBarTitle(Text(book.title), displayMode: .inline)
//        .background(Color(red: 245/255, green: 245/255, blue: 245/255))
   .onAppear {
            loadImage()
            fetchBookRatings()
        }
    }


    private var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateStyle = .long
        return formatter
    }
    
    private func fetchBookRatings() {
        let db = Firestore.firestore()
        let bookRatingRef = db.collection("BookRating").document(book.id)

        bookRatingRef.getDocument { document, error in
            guard let document = document, document.exists else {
                print("BookRating document does not exist for book ID: \(book.id)")
                return
            }

            if let ratings = document.data()?["ratings"] as? [Double] {
                let total = ratings.count
                let sum = ratings.reduce(0, +)
                self.averageRating = total > 0 ? sum / Double(total) : 0
                self.totalRatings = total
            }
        }
    }

    private func loadImage() {
        guard let imageUrl = URL(string: book.imageUrl) else { return }

        URLSession.shared.dataTask(with: imageUrl) { data, response, error in
            guard let data = data, error == nil else {
                if let error = error {
                    print("Error fetching image: \(error)")
                } else {
                    print("Unknown error fetching image")
                }
                return
            }

            DispatchQueue.main.async {
                self.bookImage = UIImage(data: data)
            }
        }.resume()
    }
}


