//
//  CheckInView.swift
//  LMS3
//
//  Created by Aditya Majumdar on 24/04/24.
//

import SwiftUI
import Firebase
import AVFoundation

struct CheckInView: View {
    @State private var memberID: String = ""
    @State private var bookBarcode: String = ""
    @State private var scannedUserID: String? = nil
    @State private var scannedBookID: String? = nil
    @State private var userName: String? = nil
    @State private var userEmail: String? = nil
    @State private var bookTitle: String? = nil
    @State private var bookAuthor: String? = nil
    @State private var bookISBN: String? = nil
    @State private var isCameraActive: Bool = false
    @State private var isScanningMemberID: Bool = false
    @State private var showAlert: Bool = false
    
    var body: some View {
        VStack {
            Text("Book Check-In")
                .font(.title).bold()
                .padding()
            ScrollView {
                
                VStack(alignment: .leading) {
                    Text("Scan / Enter Member ID")
                        .padding()
                    
                    if let userName = userName, let userEmail = userEmail {
                        Text("Member Details")
                            .font(.title2).bold()
                            .padding(.bottom,20)
                        Text("Member Name: \(userName)")
                            .font(.subheadline)
                        Text("Email: \(userEmail)")
                            .font(.subheadline)
                    } else {
                        TextField("Member ID", text: $memberID)
                            .padding()
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                    }
                }
                
                Button(action: {
                    // Action for scanning member ID
                    self.isCameraActive = true
                    self.isScanningMemberID = true
                }) {
                    
                    ZStack{
                        Rectangle()
                            .frame(width: 180,height: 50)
                            .foregroundColor(Color("Pink"))
                            .cornerRadius(15)
                        Text("Scan Member ID")
                            .foregroundColor(.white)
                        
                    }
                }
                .padding()
                
                VStack(alignment: .leading) {
                    Text("Scan / Enter Book Barcode")
                        .padding()
                    
                    if let bookTitle = bookTitle, let bookAuthor = bookAuthor, let bookISBN = bookISBN {
                        Text("Book Details")
                            .font(.title2).bold()
                            .padding(.bottom,20)
                        Text("Book Name: \(bookTitle)")
                            .font(.subheadline)
                        Text("Author(s): \(bookAuthor)")
                            .font(.subheadline)
                            .lineLimit(nil)
                        Text("ISBN: \(bookISBN)")
                            .font(.subheadline)
                    } else {
                        TextField("Book Barcode", text: $bookBarcode)
                            .padding()
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                    }
                }
                
                Button(action: {
                    // Action for scanning book barcode
                    self.isCameraActive = true
                    self.isScanningMemberID = false
                }) {
                    ZStack{
                        Rectangle()
                            .frame(width: 180,height: 50)
                            .foregroundColor(Color("Pink"))
                            .cornerRadius(15)
                        Text("Scan Barcode")
                            .foregroundColor(.white)
                        
                    }
                }
                .padding()
                
                Spacer()
                
                Button(action: {
                    // Action for saving check-in details
                    guard let memberID = scannedUserID, let bookISBN = scannedBookID else {
                        print("Member ID or Book ISBN not scanned.")
                        return
                    }
                    
                    saveCheckInDetails(memberID: memberID, bookISBN: bookISBN)
                }) {
                    ZStack{
                        Rectangle()
                            .frame(width: 250,height: 50)
                            .foregroundColor(Color("Pink"))
                            .cornerRadius(15)
                        Text("Save")
                            .font(.headline)
                            .foregroundColor(.white)
                        
                    }
                }
                .padding()
                .alert(isPresented: $showAlert) {
                    Alert(title: Text("Success"), message: Text("Check-in details saved successfully."), dismissButton: .default(Text("OK")))
                }
            }
            .sheet(isPresented: $isCameraActive, onDismiss: {
                self.isCameraActive = false
            }) {
                CameraView(isScanningMemberID: self.isScanningMemberID) { result in
                    if let barcode = result {
                        if self.isScanningMemberID {
                            self.scannedUserID = barcode
                            self.fetchMemberDetails(for: barcode)
                        } else {
                            self.scannedBookID = barcode
                            self.fetchBookDetails(for: barcode)
                        }
                    }
                    self.isCameraActive = false
                }
            }
        }
        Spacer()
    }
    
    private func fetchMemberDetails(for userID: String) {
        let db = Firestore.firestore()
        let usersRef = db.collection("Users").document(userID)
        
        usersRef.getDocument { (document, error) in
            if let document = document, document.exists {
                if let userName = document.data()?["name"] as? String {
                    self.userName = userName
                } else {
                    print("User name not found for ID: \(userID)")
                }
                
                if let userEmail = document.data()?["email"] as? String {
                    self.userEmail = userEmail
                } else {
                    print("User email not found for ID: \(userID)")
                }
            } else {
                print("User document not found or error fetching document: \(error?.localizedDescription ?? "Unknown error")")
            }
        }
    }
    
    private func fetchBookDetails(for isbn: String) {
        let db = Firestore.firestore()
        let booksRef = db.collection("books").whereField("isbn", isEqualTo: isbn)
        
        booksRef.getDocuments { (querySnapshot, error) in
            if let error = error {
                print("Error fetching book: \(error.localizedDescription)")
                return
            }
            
            guard let document = querySnapshot?.documents.first else {
                print("No book found for ISBN: \(isbn)")
                return
            }
            
            if let bookTitle = document.data()["title"] as? String {
                self.bookTitle = bookTitle
            } else {
                print("Book title not found for ISBN: \(isbn)")
            }
            
            if let authors = document.data()["authors"] as? [String] {
                        // Join the array of authors into a comma-separated string
                        let joinedAuthors = authors.joined(separator: ", ")
                        self.bookAuthor = joinedAuthors
                    } else {
                        print("Authors not found for ISBN: \(isbn)")
                    }
            
            if let bookISBN = document.data()["isbn"] as? String {
                self.bookISBN = bookISBN
            } else {
                print("Book ISBN not found for ISBN: \(isbn)")
            }
        }
    }

    private func saveCheckInDetails(memberID: String, bookISBN: String) {
        let db = Firestore.firestore()
        
        // Create a date formatter for the desired output format
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        
        // Get the current date and format it as a string in 'ddMMyyyy' format
        let currentDate = dateFormatter.string(from: Date())
        
        // Save check-in details to Firestore collection "checkindetails"
        db.collection("checkindetails").addDocument(data: [
            "memberID": memberID,
            "bookISBN": bookISBN,
            "ifcheckout": "NO",
            "checkInDate": currentDate // Store formatted date as string
        ]) { error in
            if let error = error {
                print("Error saving check-in details: \(error.localizedDescription)")
            } else {
                print("Check-in details saved successfully.")
                self.showAlert = true // Show success alert
            }
            
            // Decrease book availability in Firestore collection "books"
            let booksRef = db.collection("books").whereField("isbn", isEqualTo: bookISBN)
            
            booksRef.getDocuments { (querySnapshot, error) in
                if let error = error {
                    print("Error fetching book: \(error.localizedDescription)")
                    return
                }
                
                guard let document = querySnapshot?.documents.first else {
                    print("No book found for ISBN: \(bookISBN)")
                    return
                }
                
                var bookData = document.data()
                
                if var availability = bookData["availability"] as? Int {
                    availability -= 1
                    bookData["availability"] = availability
                    
                    // Update book document with decreased availability
                    db.collection("books").document(document.documentID).setData(bookData) { error in
                        if let error = error {
                            print("Error updating book availability: \(error.localizedDescription)")
                        } else {
                            print("Book availability decreased successfully.")
                        }
                    }
                } else {
                    print("Book availability not found or invalid.")
                }
            }
        }
    }
}
struct CameraView: View {
    let isScanningMemberID: Bool
    var completion: (String?) -> Void

    var body: some View {
        CameraViewController(isScanningMemberID: isScanningMemberID, completion: completion)
            .edgesIgnoringSafeArea(.all)
    }
}

struct CameraViewController: UIViewControllerRepresentable {
    let isScanningMemberID: Bool
    var completion: (String?) -> Void

    func makeUIViewController(context: Context) -> AVCaptureViewController {
        let vc = AVCaptureViewController(isScanningMemberID: isScanningMemberID, completion: completion)
        return vc
    }

    func updateUIViewController(_ uiViewController: AVCaptureViewController, context: Context) {
        // Update view controller
    }
}

class AVCaptureViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    var captureSession: AVCaptureSession!
    var previewLayer: AVCaptureVideoPreviewLayer!
    let isScanningMemberID: Bool
    var completion: (String?) -> Void

    init(isScanningMemberID: Bool, completion: @escaping (String?) -> Void) {
        self.isScanningMemberID = isScanningMemberID
        self.completion = completion
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = UIColor.black
        captureSession = AVCaptureSession()

        guard let videoCaptureDevice = AVCaptureDevice.default(for: .video) else {
            print("No video capture device available")
            return
        }

        guard let videoInput = try? AVCaptureDeviceInput(device: videoCaptureDevice) else {
            print("Failed to create video input")
            return
        }

        if captureSession.canAddInput(videoInput) {
            captureSession.addInput(videoInput)
        } else {
            print("Failed to add video input to capture session")
            return
        }

        let metadataOutput = AVCaptureMetadataOutput()

        if captureSession.canAddOutput(metadataOutput) {
            captureSession.addOutput(metadataOutput)
            metadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
            metadataOutput.metadataObjectTypes = [.ean13, .qr] // Set barcode types to scan (e.g., EAN-13, QR code)
        } else {
            print("Failed to add metadata output to capture session")
            return
        }

        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer.frame = view.layer.bounds
        previewLayer.videoGravity = .resizeAspectFill
        view.layer.addSublayer(previewLayer)

        captureSession.startRunning()
    }

    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        captureSession.stopRunning()

        if let metadataObject = metadataObjects.first as? AVMetadataMachineReadableCodeObject {
            let barcode = metadataObject.stringValue
            completion(barcode)
        }
    }
}


#Preview {
    CheckInView()
}
