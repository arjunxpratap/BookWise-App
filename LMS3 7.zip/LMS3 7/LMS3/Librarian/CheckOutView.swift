//
//  CheckOutView.swift
//  LMS3
//
//  Created by Aditya Majumdar on 24/04/24.
//


import SwiftUI
import Firebase
import AVFoundation

struct CheckOutView: View {
    @State private var memberID: String = ""
    @State private var bookBarcode: String = ""
    @State private var scannedUserID: String? = nil
    @State private var scannedBookID: String? = nil
    @State private var userName: String? = nil
    @State private var userEmail: String? = nil
    @State private var bookTitle: String? = nil
    @State private var bookAuthor: String? = nil
    @State private var bookISBN: String? = nil
    @State private var checkInDate: String? = nil
    @State private var dueDate: String? = nil
    @State private var isCameraActive: Bool = false
    @State private var isScanningMemberID: Bool = false
    @State private var showAlert: Bool = false
    @State private var navigateToDamagedDetails: Bool = false
    
    var body: some View {
        VStack {
            Text("Book Check-Out")
                .font(.title).bold()
                .padding()
            
            ScrollView {
                
                VStack(alignment: .leading) {
                    Text("Scan / Enter Member ID")
                        .padding()
                    
                    if let userName = userName, let userEmail = userEmail {
                        Text("Member Details")
                            .font(.title2).bold()
                            .padding(.bottom,20)
                        Text("Member Name: \(userName)")
                            .font(.subheadline)
                        Text("Email: \(userEmail)")
                            .font(.subheadline)
                    } else {
                        TextField("Member ID", text: $memberID)
                            .padding()
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                    }
                }
                
                Button(action: {
                    // Action for scanning member ID
                    self.navigateToDamagedDetails = false
                    self.isCameraActive = true
                    self.isScanningMemberID = true
                }) {
                    ZStack{
                        Rectangle()
                            .frame(width: 180,height: 50)
                            .foregroundColor(Color("Pink"))
                            .cornerRadius(15)
                        Text("Scan Member ID")
                            .foregroundColor(.white)
                    }
                }
                .padding()
                
                VStack(alignment: .leading) {
                    Text("Scan / Enter Book Barcode")
                        .padding()
                    
                    if let bookTitle = bookTitle, let bookAuthor = bookAuthor, let bookISBN = bookISBN {
                        Text("Book Details")
                            .font(.title2).bold()
                            .padding(.bottom,20)
                        Text("Book Name: \(bookTitle)")
                            .font(.subheadline)
                        Text("Author(s): \(bookAuthor)")
                            .font(.subheadline)
                            .lineLimit(nil)
                        Text("ISBN: \(bookISBN)")
                            .font(.subheadline)
                    } else {
                        TextField("Book Barcode", text: $bookBarcode)
                            .padding()
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                    }
                }
                
                Button(action: {
                    // Action for scanning book barcode
                    self.navigateToDamagedDetails = false
                    self.isCameraActive = true
                    self.isScanningMemberID = false
                }) {
                    ZStack{
                        Rectangle()
                            .frame(width: 180,height: 50)
                            .foregroundColor(Color("Pink"))
                            .cornerRadius(15)
                        Text("Scan Barcode")
                            .foregroundColor(.white)
                    }
                }
                .padding()
                
                Spacer()
                
                Button(action: {
                    // Action for saving check-out details
                    guard let memberID = scannedUserID, let bookISBN = scannedBookID else {
                        print("Member ID or Book ISBN not scanned.")
                        return
                    }
                    
                    saveCheckOutDetails(memberID: memberID, bookISBN: bookISBN)
                }) {
                    ZStack{
                        Rectangle()
                            .frame(width: 250,height: 50)
                            .foregroundColor(Color("Pink"))
                            .cornerRadius(15)
                        Text("Save")
                            .font(.headline)
                            .foregroundColor(.white)
                    }
                }
                .padding()
                .alert(isPresented: $showAlert) {
                    Alert(title: Text("Success"), message: Text("Check-out details saved successfully."), dismissButton: .default(Text("OK")))
                }
                
                if let checkInDate = checkInDate, let dueDate = dueDate {
                    VStack(alignment: .leading) {
                        Text("Issue Date: \(checkInDate)")
                        Text("Due Date: \(dueDate)")
                    }
                    .padding()
                }
            }
            .sheet(isPresented: $isCameraActive, onDismiss: {
                self.isCameraActive = false
            }) {
                CameraView(isScanningMemberID: self.isScanningMemberID) { result in
                    if let barcode = result {
                        if self.isScanningMemberID {
                            self.scannedUserID = barcode
                            self.fetchMemberDetails(for: barcode)
                        } else {
                            self.scannedBookID = barcode
                            self.fetchBookDetails(for: barcode)
                        }
                    }
                    self.isCameraActive = false
                }
            }
        }
        .sheet(isPresented: $navigateToDamagedDetails) {
                    DamagedDetails(memberID: self.scannedUserID ?? "", bookISBN: self.bookISBN ?? "")
                }
        Spacer()
    }
    
    private func fetchMemberDetails(for userID: String) {
        let db = Firestore.firestore()
        let usersRef = db.collection("Users").document(userID)
        
        usersRef.getDocument { (document, error) in
            if let document = document, document.exists {
                if let userName = document.data()?["name"] as? String {
                    self.userName = userName
                } else {
                    print("User name not found for ID: \(userID)")
                }
                
                if let userEmail = document.data()?["email"] as? String {
                    self.userEmail = userEmail
                } else {
                    print("User email not found for ID: \(userID)")
                }
            } else {
                print("User document not found or error fetching document: \(error?.localizedDescription ?? "Unknown error")")
            }
        }
    }
    
    private func fetchBookDetails(for isbn: String) {
        let db = Firestore.firestore()
        let booksRef = db.collection("books").whereField("isbn", isEqualTo: isbn)
        
        booksRef.getDocuments { (querySnapshot, error) in
            if let error = error {
                print("Error fetching book: \(error.localizedDescription)")
                return
            }
            
            guard let document = querySnapshot?.documents.first else {
                print("No book found for ISBN: \(isbn)")
                return
            }
            
            if let bookTitle = document.data()["title"] as? String {
                self.bookTitle = bookTitle
            } else {
                print("Book title not found for ISBN: \(isbn)")
            }
            
            if let authors = document.data()["authors"] as? [String] {
                // Join the array of authors into a comma-separated string
                let joinedAuthors = authors.joined(separator: ", ")
                self.bookAuthor = joinedAuthors
            } else {
                print("Authors not found for ISBN: \(isbn)")
            }
            
            if let bookISBN = document.data()["isbn"] as? String {
                self.bookISBN = bookISBN
            } else {
                print("Book ISBN not found for ISBN: \(isbn)")
            }
            
            // Fetch check-in date for the book and member
            self.fetchCheckInDate(memberID: self.memberID, bookISBN: isbn) { checkInDate in
            }
        }
    }
    
    private func fetchCheckInDate(memberID: String, bookISBN: String, completion: @escaping (String?) -> Void) {
        let db = Firestore.firestore()
        
        // Query Firestore to fetch the check-in date
        let checkInDetailsRef = db.collection("checkindetails")
            .whereField("memberID", isEqualTo: memberID)
            .whereField("bookISBN", isEqualTo: bookISBN)
            .limit(to: 1)
        
        checkInDetailsRef.getDocuments { (querySnapshot, error) in
            if let error = error {
                print("Error fetching check-in details: \(error.localizedDescription)")
                completion(nil)
                return
            }
            
            guard let document = querySnapshot?.documents.first else {
                print("No check-in details found for memberID: \(memberID) and bookISBN: \(bookISBN)")
                completion(nil)
                return
            }
            
            if let checkInDate = document.data()["checkInDate"] as? String {
                completion(checkInDate)
            } else {
                print("Check-in date not found for memberID: \(memberID) and bookISBN: \(bookISBN)")
                completion(nil)
            }
        }
    }
    
    private func dateFromString(dateString: String) -> Date? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        return dateFormatter.date(from: dateString)
    }
    
    private func stringFromDate(date: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        return dateFormatter.string(from: date)
    }
    
    
    private func saveCheckOutDetails(memberID: String, bookISBN: String) {
        let db = Firestore.firestore()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        
        // Fetch check-in date and calculate due date
        fetchCheckInDate(memberID: memberID, bookISBN: bookISBN) { checkInDate in
            guard let checkInDate = checkInDate else {
                print("Failed to retrieve check-in date.")
                return
            }
            
            // Convert check-in date string to Date object
            guard let issueDate = dateFormatter.date(from: checkInDate) else {
                print("Failed to convert check-in date to Date object.")
                return
            }
            
            // Calculate due date (issueDate + 7 days)
            let dueDate = Calendar.current.date(byAdding: .day, value: 7, to: issueDate)
            let formattedDueDate = dateFormatter.string(from: dueDate ?? Date())
            let currentDate = dateFormatter.string(from: Date())
            
            // Save check-out details to Firestore collection "checkoutdetail"
            db.collection("checkoutdetail").addDocument(data: [
                "memberID": memberID,
                "bookISBN": bookISBN,
                "checkInDate": checkInDate,
                "dueDate": formattedDueDate,
                "returnDate": currentDate // This will be updated later
            ]) { error in
                if let error = error {
                    print("Error saving check-out details: \(error.localizedDescription)")
                    return
                }
                
                print("Check-out details saved successfully.")
                self.showAlert = true // Show success alert
                
                // Set the return date to the current date
                
                // Update the return date for the checkout detail document
                db.collection("checkoutdetail").whereField("memberID", isEqualTo: memberID)
                    .whereField("bookISBN", isEqualTo: bookISBN)
                    .getDocuments { (querySnapshot, error) in
                        if let error = error {
                            print("Error fetching check-out details for updating return date: \(error.localizedDescription)")
                            return
                        }
                        
                        guard let document = querySnapshot?.documents.first else {
                            print("No check-out details found for memberID: \(memberID) and bookISBN: \(bookISBN)")
                            return
                        }
                        
                        let checkoutDetailRef = db.collection("checkoutdetail").document(document.documentID)
                        checkoutDetailRef.updateData(["returnDate": currentDate]) { error in
                            if let error = error {
                                print("Error updating return date: \(error.localizedDescription)")
                            } else {
                                print("Return date updated successfully.")
                                
                                // Increase book availability by 1
                                let booksRef = db.collection("books").whereField("isbn", isEqualTo: bookISBN)
                                
                                booksRef.getDocuments { (querySnapshot, error) in
                                    if let error = error {
                                        print("Error fetching book: \(error.localizedDescription)")
                                        return
                                    }
                                    
                                    guard let document = querySnapshot?.documents.first else {
                                        print("No book found for ISBN: \(bookISBN)")
                                        return
                                    }
                                    
                                    var bookData = document.data()
                                    
                                    if var availability = bookData["availability"] as? Int {
                                        availability += 1
                                        bookData["availability"] = availability
                                        
                                        // Update book document with increased availability
                                        db.collection("books").document(document.documentID).setData(bookData) { error in
                                            if let error = error {
                                                print("Error updating book availability: \(error.localizedDescription)")
                                            } else {
                                                print("Book availability increased successfully.")
                                                
                                                // Update ifcheckout field in checkindetails to "YES"
                                                let checkInDetailsRef = db.collection("checkindetails")
                                                    .whereField("memberID", isEqualTo: memberID)
                                                    .whereField("bookISBN", isEqualTo: bookISBN)
                                                
                                                checkInDetailsRef.getDocuments { (querySnapshot, error) in
                                                    if let error = error {
                                                        print("Error fetching check-in details for updating ifcheckout: \(error.localizedDescription)")
                                                        return
                                                    }
                                                    
                                                    guard let document = querySnapshot?.documents.first else {
                                                        print("No check-in details found for memberID: \(memberID) and bookISBN: \(bookISBN)")
                                                        return
                                                    }
                                                    
                                                    let checkInDetailRef = db.collection("checkindetails").document(document.documentID)
                                                    checkInDetailRef.updateData(["ifcheckout": "YES"]) { error in
                                                        if let error = error {
                                                            print("Error updating ifcheckout field: \(error.localizedDescription)")
                                                        } else {
                                                            print("ifcheckout field updated successfully.")
                                                            self.navigateToDamagedDetails = true
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    } else {
                                        print("Book availability not found or invalid.")
                                    }
                                }
                            }
                        }
                    }
            }
        }
    }
}

#Preview {
    CheckOutView()
}
