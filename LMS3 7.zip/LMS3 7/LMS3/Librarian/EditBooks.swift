//
//  EditBooks.swift
//  LMS3
//
//  Created by Aditya Majumdar on 25/04/24.
//

import SwiftUI
import Firebase
import FirebaseFirestore
import SDWebImageSwiftUI

struct EditBookView: View {
    let db = Firestore.firestore()
    let book: Book
    
    @State private var bookId: String
    @State private var bookName: String
    @State private var authorNames: [String]
    @State private var description: String
    @State private var publication: String
    @State private var publicationDate: String
    @State private var category: String
    @State private var quantity: Int
    @State private var availability: Int
    @State private var edition: String
    @State private var bookImageData: Data?
    @State private var showImagePicker = false
    @State private var imageUrl: String
    @State private var price:Double
    @State private var shelfNumber: String
    @Environment(\.presentationMode) var presentationMode
    
    init(book: Book) {
        self.book = book
        self._bookId = State(initialValue: book.id)
        self._bookName = State(initialValue: book.title)
        self._authorNames = State(initialValue: book.authors)
        self._description = State(initialValue: book.description)
        self._publication = State(initialValue: book.publisher)
        self._publicationDate = State(initialValue: book.publicationDate)
        self._category = State(initialValue: book.selectedCategory)
        self._quantity = State(initialValue: book.quantity)
        self._availability = State(initialValue: book.availability)
        self._edition = State(initialValue: book.edition)
        self._imageUrl = State(initialValue: book.imageUrl)
        self._price = State(initialValue: book.price)
        self._shelfNumber = State(initialValue: book.shelfNumber)
    }
    
    
    
    var body: some View {
        ScrollView {
            VStack(alignment:.leading, spacing: 20) {
                Text("Edit Book")
                    .font(.largeTitle).bold()
                    .padding(.top)
                
                Group {
                    HStack {
                        VStack(alignment:.leading) {
                            Text("Book Name")
                                .font(.headline)
                            LabeledTextField(text: $bookName)
                                .padding(.leading,-16)
                              
                        }
                        VStack(alignment:.leading) {
                            Text("Book Id")
                                .font(.headline)
                            LabeledTextField(text: $bookId)
                                .padding(.leading,-16)
                        }
                    }
                    
                    HStack {
                        VStack(alignment: .leading) {
                            Text("Authors")
                                .font(.headline)
                                .padding(.bottom,40)
                            
                            ForEach(authorNames.indices, id: \.self) { index in
                                TextField("Author \(index + 1)", text: Binding(
                                    get: { self.authorNames[index] },
                                    set: { self.authorNames[index] = $0 }
                                ))
                                .padding()
                                .background(Color.gray.opacity(0.2))
                                .cornerRadius(10)
                                .padding(.horizontal)
                            }
                            
                            Button(action: {
                                self.authorNames.append("")
                            }) {
                                Text("Add Author")
                                    .foregroundColor(.blue)
                            }
                        }
                        VStack(alignment:.leading) {
                            Text("Edition")
                                .font(.headline)
                            LabeledTextField(text: $edition)
                                .padding(.leading,-16)

                        }
                    }
                    
                    VStack(alignment:.leading) {
                        Text("Description")
                            .font(.headline)
                        TextField("", text: $description)
                            .padding()
                            .background(Color.gray.opacity(0.2))
                            .cornerRadius(10)
                            //.padding(.horizontal)
                    }
                }
                
                HStack(spacing: 20) {
                    VStack(alignment:.leading) {
                        Text("Publication")
                            .font(.headline)
                        LabeledTextField(text: $publication)
                            .padding(.leading,-16)
                    }
                    VStack(alignment:.leading) {
                        Text("Publication Date")
                            .font(.headline)
                        LabeledTextField(text: $publicationDate)
                            .padding(.leading,-15)
                            .padding(.trailing,-16)
                    }
                }
                
                HStack(spacing: 20) {
                    VStack(alignment: .leading) {
                        Text("Price")
                            .font(.headline)
                        LabeledTextField(text: Binding<String>(
                            get: { String(price) },
                            set: { newValue in
                                if let value = Double(newValue) {
                                    price = value
                                }
                            }
                        ))
                        .padding(.leading,-15)
                                          .padding(.trailing,-10)

                    }
                    VStack(alignment:.leading) {
                        Text("Shelf Number")
                            .font(.headline)
                        LabeledTextField(text: $shelfNumber)
                            .padding(.leading,-15)
                            .padding(.trailing,-10)
                    }
                }
                
                HStack(spacing: 20) {
                    VStack(alignment:.leading) {
                        Text("Category")
                            .font(.headline)
                        CategoryPicker(category: $category)
                    }
                    Spacer()
                    VStack(alignment:.trailing) {
                        Text("Quantity")
                            .font(.headline)
                            .padding(.leading,-170)
                        HStack {
                            Stepper(value: $quantity, in: 0...100) {
                                EmptyView()
                            }.padding(.leading,-170)
                            Text("\(quantity)").padding(.leading,-170)
                        }
                    }
                }
                
                HStack {
                    VStack {
                        Text("Book photo")
                            .bold()
                            .padding(.leading,-5)
                        if let imageData = bookImageData {
                            Image(uiImage: UIImage(data: imageData)!)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100, height: 100)
                                .clipped()
                                .cornerRadius(10)
                                .onTapGesture {
                                    self.showImagePicker = true
                                }
                        } else {
                            Button(action: {
                                self.showImagePicker = true
                            }) {
                                //Text("Select Image")
                                Image(systemName: "square.and.arrow.up")
                                  .padding(.leading,30)
                                  .padding(.top,7)
                            }
                        }
                    }
                    .sheet(isPresented: $showImagePicker) {
                        ImagePickerBook(imageData: self.$bookImageData)
                    }
                    
                    Spacer()
                    VStack(alignment:.trailing) {
                        Text("Availability")
                            .font(.headline)
                            .padding(.leading,-170)

                        HStack {
                            Stepper(value: $availability, in: 0...100) {
                                EmptyView()
                            }.padding(.leading,-170)
                            Text("\(availability)").padding(.leading,-170)
                        }
                    }
                }
                
                Button(action: saveChanges) {
                    Text("Save")
                        .foregroundColor(.white)
                        .frame(maxWidth:.infinity)
                        .padding()
                        .background(Color("Pink"))
                        .cornerRadius(15)
                }
                .padding(.bottom)
            }
            .padding()
        }
        .background(Color.white)
        .cornerRadius(40)
        .onAppear {
            // Fetch book details on view appear
            fetchBookDetails()
        }
    }
    func fetchBookDetails() {
        // Fetch the specific book document from Firestore using book ID
        db.collection("books").document(book.id).getDocument { (document, error) in
            if let document = document, document.exists {
                do {
                    if let bookData = try? document.data(as: Book.self) {
                        // Update state variables with fetched book details
                        self.bookName = bookData.title
                        self.authorNames = bookData.authors
                        self.description = bookData.description
                        self.publication = bookData.publisher
                        self.publicationDate = bookData.publicationDate
                        self.category = bookData.selectedCategory
                        self.quantity = bookData.quantity
                        self.availability = bookData.availability
                        self.edition = bookData.edition
                        self.imageUrl = bookData.imageUrl
                        self.price = bookData.price
                        self.shelfNumber = bookData.shelfNumber
                    } else {
                        print("Document data does not match Book structure")
                    }
                } catch {
                    print("Error decoding book: \(error)")
                }
            } else {
                print("Document does not exist")
            }
        }
    }
    
    // Save changes to Firestore
    func saveChanges() {
        // Create a query to find the document with the matching ISBN
        db.collection("books")
            .whereField("isbn", isEqualTo: book.id) // Assuming "isbn" is the field to match
            .getDocuments { querySnapshot, error in
                if let error = error {
                    print("Error getting documents: \(error.localizedDescription)")
                } else {
                    // Iterate through the query results
                    for document in querySnapshot!.documents {
                        // Update Firestore document with edited book details
                        let documentID = document.documentID
                        let updatedFields: [String: Any] = [
                            "title": bookName,
                            "authors": authorNames,
                            "description": description,
                            "publisher": publication,
                            "publicationDate": publicationDate,
                            "selectedCategory": category,
                            "quantity": quantity,
                            "availability": availability,
                            "edition": edition,
                            "imageUrl": imageUrl,
                            "price": price,
                            "shelfNumber": shelfNumber
                        ]
                        
                        // Update the document with the new values
                        db.collection("books").document(documentID).setData(updatedFields, merge: true) { error in
                            if let error = error {
                                print("Error updating document: \(error.localizedDescription)")
                            } else {
                                print("Book updated successfully!")
                                self.presentationMode.wrappedValue.dismiss()
                            }
                        }
                    }
                }
            }
    }
}

struct EditBookView_Previews: PreviewProvider {
    static var previews: some View {
        AddBookView()
    }
}
