//
//  LibrarianHomeView.swift
//  LMS3
//
//  Created by Aditya Majumdar on 23/04/24.
//

import SwiftUI
import SDWebImageSwiftUI
import Firebase
import FirebaseFirestore
import FirebaseFirestoreSwift
import FirebaseStorage

struct Book: Identifiable, Codable {
    var id: String
    var title: String
    var description: String
    var edition: String
    var genre: String
    var selectedCategory: String
    var quantity: Int
    var availability: Int
    var publicationDate: String
    var publisher: String
    var authors: [String]
    var imageUrl: String
    var price: Double
    var shelfNumber: String
}

struct LibrarianHomeView: View {
    @State private var categories: [Category] = []
    @State private var selectedCategory: Category?
    @State private var isAccountScreenPresented = false
    private let db = Firestore.firestore()

    var body: some View {
            VStack {
                HStack {
                    Text("Home")
                        .font(.largeTitle)
                        .bold()
                        .padding()
                    Spacer()
                    Image(systemName: "person.circle.fill")
                        .font(.custom("SF Pro", size: 44))
                        .padding(.trailing,10)
                        .onTapGesture {
                            isAccountScreenPresented = true
                        }
                }
                HStack {
                    Text("Catalog")
                        .font(.title)
                        .bold()
                    Spacer()
                }
                .padding(.horizontal)

                List {
                    ForEach(categories) { category in
                        NavigationLink(destination: CategoryDetailView(category: category)) {
                            CategoryRowViewLibrarian(category: category)
                        }
                    }
                }
                .listStyle(PlainListStyle())
            }
            .background(
                            NavigationLink(
                                destination: AccountScreenLib(),
                                isActive: $isAccountScreenPresented
                            ) {
                                EmptyView()
                            }
                        )
            .onAppear {
                fetchCategories()
            }
    }

    private func fetchCategories() {
        db.collection("categories").addSnapshotListener { querySnapshot, error in
            guard let documents = querySnapshot?.documents else {
                print("Error fetching categories: \(error?.localizedDescription ?? "")")
                return
            }

            categories = documents.compactMap { queryDocumentSnapshot -> Category? in
                try? queryDocumentSnapshot.data(as: Category.self)
            }
        }
    }
}

struct CategoryRowViewLibrarian: View {
    let category: Category

    var body: some View {
        HStack {
            if let imageUrl = URL(string: category.imageUrl) {
                AsyncImage(url: imageUrl)
                    .frame(width: 100, height: 100)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .padding(.trailing)
            } else {
                Image(systemName: "photo")
                    .resizable()
                    .frame(width: 100, height: 100)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .padding(.trailing)
            }

            Text(category.name)
                .font(.headline)

            Spacer()
        }
        .frame(height: 105)
        .cornerRadius(15)
    }
}

struct CategoryDetailView: View {
    let category: Category
    @State private var books: [Book] = []
    @State private var selectedBook: Book?
    @State private var isBookDetailViewPresented = false
    private let db = Firestore.firestore()
    
    var body: some View {
        VStack {
            HStack{
                Text(category.name)
                    .font(.largeTitle).bold()
                    .padding()
                
                Spacer()
                
                
                AddBooksView(category: category)
            }
            
            if books.isEmpty {
                Text("No Books Found")
                    .padding()
            }
            else {
                List {
                    ForEach(books) { book in
                        NavigationLink(destination: BookDetailView(book: book)){
                            BookRowView(book: book)
                        }
                    }
                    .onDelete(perform: deleteBook)
                }
                .listStyle(PlainListStyle())
            }
            Spacer()
        }
                    .onAppear {
                        fetchBooks()
                    }
                }
    private func deleteBook(at indexSet: IndexSet) {
        guard let index = indexSet.first else { return }
        let book = books[index]

        // Delete the book document from Firestore based on its ISBN
        db.collection("books")
            .whereField("isbn", isEqualTo: book.id)
            .getDocuments { snapshot, error in
                if let error = error {
                    print("Error deleting book: \(error.localizedDescription)")
                    return
                }

                guard let documents = snapshot?.documents else {
                    print("No book found to delete")
                    return
                }

                for document in documents {
                    document.reference.delete { error in
                        if let error = error {
                            print("Error deleting book document: \(error.localizedDescription)")
                        } else {
                            // Book document successfully deleted
                            print("Book deleted successfully!")
                        }
                    }
                }
            }
    }

    
    private func fetchBooks() {
        db.collection("books")
            .whereField("selectedCategory", isEqualTo: category.name)
            .addSnapshotListener { querySnapshot, error in
                if let error = error {
                    print("Error fetching books: \(error.localizedDescription)")
                    return
                }

                guard let documents = querySnapshot?.documents else {
                    print("No books found")
                    return
                }

                books = documents.compactMap { queryDocumentSnapshot -> Book? in
                    do {
                        // Attempt to decode Firestore document into a Book model
                        let book = try queryDocumentSnapshot.data(as: Book.self)
                        return book
                    } catch {
                        print("Error decoding book: \(error.localizedDescription)")
                        return nil
                    }
                }
            }
    }

}

struct AddBooksView: View {
    let category: Category
    @State private var isManualAddPresented = false
    @State private var isScannerLinkActive = false

    var body: some View {
        VStack {
            NavigationLink(
                destination: AddBookView(),
                isActive: $isManualAddPresented,
                label: {
                    EmptyView()
                }
            )
            
            Menu {
                Button(action: {
                    isManualAddPresented = true
                }) {
                    Label("Add Manually", systemImage: "doc.text")
                }

                Button(action: {
                    isScannerLinkActive = true
                }) {
                    Label("Scan Barcode", systemImage: "barcode.viewfinder")
                }
            } label: {
                HStack {
                    Text("Add Books")
                        .foregroundColor(Color(red: 228/255, green: 133/255, blue: 135/255))

                    Image(systemName: "chevron.down")
                        .foregroundColor(Color(red: 228/255, green: 133/255, blue: 135/255))
                }
                .padding()
            }
            .menuStyle(BorderlessButtonMenuStyle())
        }
        .background(
            NavigationLink(
                destination: BookScannerView(category: category),
                isActive: $isScannerLinkActive
            ) {
                EmptyView()
            }
        )
    }
}



struct BookRowView: View {
    let book: Book
    @State private var image: UIImage? = nil

    var body: some View {
        HStack {
            if let image = image {
                Image(uiImage: image)
                    .resizable()
                    .frame(width: 80, height: 120)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .padding(.trailing)
            } else {
                Image(systemName: "photo")
                    .resizable()
                    .frame(width: 80, height: 120)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .padding(.trailing)
            }

            VStack(alignment: .leading) {
                Text(book.title)
                    .font(.headline)
                Text(book.authors.joined(separator: ", "))
                    .font(.subheadline)
            }

            Spacer()
            
            HStack {
                        VStack {
                            Text("\(book.quantity)")
                                .font(.subheadline)
                                .foregroundColor(.white)
                                .padding(5)
                                .background(Color(red: 228/255, green: 133/255, blue: 135/255))
                                .clipShape(RoundedRectangle(cornerRadius: 5))
                            Text("Quantity")
                                .font(.caption2)
                           
                        }
                        VStack {
                            Text("\(book.availability)")
                                .font(.subheadline)
                                .foregroundColor(.white)
                                .padding(5)
                                .background(Color(red: 228/255, green: 133/255, blue: 135/255))
                                .clipShape(RoundedRectangle(cornerRadius: 5))
                            Text("Available")
                                .font(.caption2)
                            
                        }
                    }
                    .padding(.trailing, 8)
        }
        .onAppear {
            loadImage()
        }
        .frame(height: 125)
        .cornerRadius(15)
    }

    private func loadImage() {
        guard let imageUrl = URL(string: book.imageUrl) else { return }
        
        URLSession.shared.dataTask(with: imageUrl) { data, response, error in
            guard let data = data, error == nil else {
                if let error = error {
                    print("Error fetching image: \(error)")
                } else {
                    print("Unknown error fetching image")
                }
                return
            }
            
            DispatchQueue.main.async {
                self.image = UIImage(data: data)
            }
        }.resume()
    }
}

struct LibrarianHomeView_Previews: PreviewProvider {
    static var previews: some View {
        LibrarianHomeView()
    }
}
