//
//  FinesPage.swift
//  LMS3
//
//  Created by Aditya Majumdar on 03/05/24.
//

import SwiftUI
import Firebase

struct DamagedDetails: View {
    @Environment(\.presentationMode) var presentationMode
    @StateObject private var viewModel: DamagedDetailsViewModel
    
    init(memberID: String, bookISBN: String) {
        let viewModel = DamagedDetailsViewModel(memberID: memberID, bookISBN: bookISBN)
        _viewModel = StateObject(wrappedValue: viewModel)
    }
    
    var body: some View {
        NavigationView {
            VStack {
                Text("Fine Details").bold()
                    .font(.largeTitle)
                    .padding(.top, 20)
                
                RoundedRectangle(cornerRadius: 16)
                    .fill(Color.gray.opacity(0.2))
                    .frame(width: 370, height: 75)
                    .overlay(
                        HStack {
                            VStack(alignment:.leading,spacing:-5.5){
                                HStack{
                                    Circle()
                                        .strokeBorder(Color.black, lineWidth: 1)
                                        .background(Circle()
                                        .foregroundColor(Color.white))
                                        .frame(width: 10, height: 10)
                                    Spacer()
                                    Text("\(viewModel.checkInDate)")
                                        .font(.subheadline)
                                        .padding(.trailing,10)
                                }
                                Rectangle()
                                    .fill(Color.black)
                                    .frame(width: 1, height: 25)
                                    .padding(.leading,4.5)
                                HStack{
                                    Circle()
                                        .fill(viewModel.returnDate.isEmpty ? Color.red : Color.black)
                                        .frame(width: 10, height:10)
                                    Spacer()
                                    Text("\(viewModel.returnDate)")
                                        .font(.subheadline)
                                        .padding(.trailing,10)
                                }
                            }.padding(.horizontal)
                        }
                    )
                
                RoundedRectangle(cornerRadius: 16)
                    .fill(Color.gray.opacity(0.2))
                    .frame(width: 370, height: 50)
                    .overlay(
                        HStack {
                            Text("Fine")
                                .padding(.leading, 8)
                            Spacer()
                            Text("₹\(viewModel.fine)")
                                .padding(.trailing, 8)
                        }
                    )
                
                RoundedRectangle(cornerRadius: 16)
                    .fill(Color.gray.opacity(0.2))
                    .frame(width: 370, height: 50)
                    .overlay(
                        HStack {
                            Text("Damaged")
                                .padding(.leading, 8)
                            Spacer()
                            Toggle("", isOn: $viewModel.isDamaged)
                                .padding(.trailing, 8)
                        }
                    )
                    .onChange(of: viewModel.isDamaged) { newValue in
                                            viewModel.toggleStateChanged(isDamaged: newValue, isLost: viewModel.isLost)
                                        }
                
                Text("OR")
                    .font(.subheadline)
                
                RoundedRectangle(cornerRadius: 16)
                    .fill(Color.gray.opacity(0.2))
                    .frame(width: 370, height: 50)
                    .overlay(
                        HStack {
                            Text("Lost")
                                .padding(.leading, 8)
                            Spacer()
                            Toggle("", isOn: $viewModel.isLost)
                                .padding(.trailing, 8)
                        }
                    )
                    .onChange(of: viewModel.isLost) { newValue in
                                            viewModel.toggleStateChanged(isDamaged: viewModel.isDamaged, isLost: newValue)
                                        }
                
                HStack {
                    RoundedRectangle(cornerRadius: 6)
                        .fill(Color(#colorLiteral(red: 0.8941176533699036, green: 0.5215686559677124, blue: 0.529411792755127, alpha: 1)))
                        .frame(width: 100, height: 34)
                        .overlay(
                            Button(action: {
                                viewModel.updateFineStatus(status: "Due")
                                presentationMode.wrappedValue.dismiss()
                            }) {
                                Text("Due")
                                    .foregroundColor(.white)
                            }
                        )
                        .padding(.leading, 50)
                        .padding(.trailing, 50)
                    Spacer()
                    
                    RoundedRectangle(cornerRadius: 6)
                        .fill(Color(#colorLiteral(red: 0.8941176533699036, green: 0.5215686559677124, blue: 0.529411792755127, alpha: 1)))
                        .frame(width: 100, height: 34)
                        .overlay(
                            Button(action: {
                                viewModel.updateFineStatus(status: "Paid")
                                presentationMode.wrappedValue.dismiss()
                            }) {
                                Text("Paid")
                                    .foregroundColor(.white)
                            }
                        )
                        .padding(.trailing)
                        .padding()
                }
            }
            .padding(.top, -350)
        }
        .background(Color.gray.opacity(0.2))
    }
}

class DamagedDetailsViewModel: ObservableObject {
    @Published var dueDate = ""
    @Published var returnDate = ""
    @Published var checkInDate = ""
    @Published var fine = ""
    @Published var isDamaged = false
    @Published var isLost = false
    
    private let memberID: String
    private let bookISBN: String
    private var damagedBooksPercentage: Int = 0
    private var bookPrice: Int = 0
    private var lostBooksPercentage: Int = 0
    
    init(memberID: String, bookISBN: String) {
        self.memberID = memberID
        self.bookISBN = bookISBN
        fetchCheckInDate()
        fetchDamagedBooksPercentage()
        fetchLostBooksPercentage()
        fetchBookPrice()
    }
    
    private func fetchCheckInDate() {
        let db = Firestore.firestore()
        let checkInDetailsRef = db.collection("checkindetails")
            .whereField("memberID", isEqualTo: memberID)
            .whereField("bookISBN", isEqualTo: bookISBN)
            .limit(to: 1)
        
        checkInDetailsRef.getDocuments { [weak self] (querySnapshot, error) in
            guard let self = self else { return }
            if let error = error {
                print("Error fetching check-in details: \(error.localizedDescription)")
                return
            }
            
            guard let document = querySnapshot?.documents.first else {
                print("No check-in details found for memberID: \(self.memberID) and bookISBN: \(self.bookISBN)")
                return
            }
            
            if let checkInDate = document.data()["checkInDate"] as? String {
                DispatchQueue.main.async {
                    self.fetchDueAndReturnDates(checkInDate: checkInDate)
                }
            } else {
                print("Check-in date not found for memberID: \(self.memberID) and bookISBN: \(self.bookISBN)")
            }
        }
    }
    
    private func fetchDueAndReturnDates(checkInDate: String) {
        let db = Firestore.firestore()
        db.collection("checkoutdetail")
            .whereField("memberID", isEqualTo: memberID)
            .whereField("bookISBN", isEqualTo: bookISBN)
            .whereField("checkInDate", isEqualTo: checkInDate)
            .getDocuments { [weak self] (querySnapshot, error) in
                guard let self = self else { return }
                guard let documents = querySnapshot?.documents else {
                    print("Error fetching documents: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }
                for document in documents {
                    if let dueDate = document.data()["dueDate"] as? String {
                        self.dueDate = dueDate
                    }
                    if let checkInDate = document.data()["checkInDate"] as? String {
                        self.checkInDate = checkInDate
                    }
                    if let returnDate = document.data()["returnDate"] as? String {
                        self.returnDate = returnDate
                    }
                }
                self.calculateOverdueFine()
            }
    }
    
    private func fetchDamagedBooksPercentage() {
        let db = Firestore.firestore()
        db.collection("Fine")
            .document("fine_configuration")
            .getDocument { [weak self] (document, error) in
                guard let self = self else { return }
                if let document = document, document.exists {
                    if let percentage = document.data()?["damagedBooksPercentage"] as? Int {
                        self.damagedBooksPercentage = percentage
                    } else {
                        print("Damaged books percentage not found")
                    }
                } else {
                    print("Fine document does not exist")
                }
            }
    }
    
    private func fetchLostBooksPercentage() {
        let db = Firestore.firestore()
        db.collection("Fine")
            .document("fine_configuration")
            .getDocument { [weak self] (document, error) in
                guard let self = self else { return }
                if let document = document, document.exists {
                    if let percentage = document.data()?["lostBooksPercentage"] as? Int {
                        self.lostBooksPercentage = percentage
                    } else {
                        print("Lost books percentage not found")
                    }
                } else {
                    print("Fine document does not exist")
                }
            }
    }
    
    private func fetchBookPrice() {
        let db = Firestore.firestore()
        db.collection("books")
            .whereField("isbn", isEqualTo: bookISBN)
            .getDocuments { [weak self] (querySnapshot, error) in
                guard let self = self else { return }
                if let error = error {
                    print("Error fetching book: \(error.localizedDescription)")
                    return
                }
                
                guard let document = querySnapshot?.documents.first else {
                    print("No book found for ISBN: \(self.bookISBN)")
                    return
                }
                
                if let price = document.data()["price"] as? Int {
                    self.bookPrice = price
                } else {
                    print("Book price not found or invalid.")
                }
            }
    }
    
    private func calculateOverdueFine() {
        // Calculate overdue days and fetch lateReturnFixedAmount
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        
        guard let due = dateFormatter.date(from: dueDate),
              let returnDate = dateFormatter.date(from: returnDate) else {
            print("Error converting dates")
            return
        }
        
        let overdueDays = Calendar.current.dateComponents([.day], from: due, to: returnDate).day ?? 0
        
        let db = Firestore.firestore()
        db.collection("Fine")
            .document("fine_configuration")
            .getDocument { [weak self] (document, error) in
                guard let self = self else { return }
                if let document = document, document.exists {
                    if let lateReturnFixedAmount = document.data()?["lateReturnFixedAmount"] as? Int {
                        DispatchQueue.main.async {
                            self.fine = "\(overdueDays * lateReturnFixedAmount)"
                            if let fineInt = Int(self.fine), fineInt < 0 {
                                self.fine = "0"
                            }
                        }
                    } else {
                        print("Late return fixed amount not found")
                    }
                } else {
                    print("Fine document does not exist")
                }
            }
    }
    
    func toggleStateChanged(isDamaged: Bool, isLost: Bool) {
        if isDamaged {
            self.isLost = false
            updateFine()
        } else if isLost {
            self.isDamaged = false
            updateFine()
        } else {
            // Both are off
            calculateOverdueFine()
        }
    }
    
    private func updateFine() {
        if isDamaged {
            calculateAndAddDamagedFine()
        } else if isLost {
            calculateAndAddLostFine()
        } else {
            // Both are off
            calculateOverdueFine()
        }
    }
    
    private func calculateAndAddDamagedFine() {
        let damagedFine = Double(damagedBooksPercentage) / 100.0 * Double(bookPrice)
        let currentFine = Double(fine) ?? 0.0
        let totalFine = currentFine + damagedFine
        DispatchQueue.main.async {
            self.fine = String(format: "%.2f", totalFine)
        }
    }
    
    private func calculateAndAddLostFine() {
        let lostFine = Double(lostBooksPercentage) / 100.0 * Double(bookPrice)
        let currentFine = Double(fine) ?? 0.0
        let totalFine = currentFine + lostFine
        DispatchQueue.main.async {
            self.fine = String(format: "%.2f", totalFine)
        }
    }
    
    func updateFineStatus(status: String) {
        let db = Firestore.firestore()
        let fineDetailsRef = db.collection("FineDetails")
        
        fineDetailsRef.addDocument(data: [
            "bookISBN": bookISBN,
            "Date": returnDate,
            "memberID": memberID,
            "fineAmount": fine,
            "fineStatus": status
        ]) { error in
            if let error = error {
                print("Error adding document: \(error.localizedDescription)")
            } else {
                print("Fine details added successfully!")
            }
        }
    }
}
